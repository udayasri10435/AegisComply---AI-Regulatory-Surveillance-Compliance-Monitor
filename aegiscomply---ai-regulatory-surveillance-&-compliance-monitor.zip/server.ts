import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '10mb' }));

const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Fallback rule-based compliance analyzer if Gemini is not reachable or fails
function runFallbackAnalysis(content: string, type: string, channel: string): any {
  const lower = content.toLowerCase();
  const flaggedSnippets: Array<{ text: string; riskReason: string; riskLevel: string }> = [];
  const regulations: Array<{ code: string; title: string; agency: string; severity: string; summary: string }> = [];
  let severity = 'clean';
  let riskScore = 8;
  let domain = 'CLEAN';
  let category = 'Compliant Activity';
  let intentAssessment = 'benign';

  // 1. Off-Channel Comms (SEC Rule 17a-4 / FINRA 3110)
  if (lower.includes('signal') || lower.includes('whatsapp') || lower.includes('telegram') || lower.includes('personal phone') || lower.includes('off book') || lower.includes('text me on my cell')) {
    severity = 'high';
    riskScore = Math.max(riskScore, 82);
    domain = 'SEC';
    category = 'Unapproved Off-Channel Communication';
    intentAssessment = 'intentional';
    regulations.push({
      code: 'SEC Rule 17a-4 / Exchange Act § 17(a)',
      title: 'Electronic Recordkeeping & Off-Channel Communication Ban',
      agency: 'SEC',
      severity: 'high',
      summary: 'Prohibits broker-dealers and investment advisers from conducting commercial communications over unarchived personal or ephemeral channels.'
    });
    regulations.push({
      code: 'FINRA Rule 3110',
      title: 'Supervisory Systems for Correspondence and Internal Communications',
      agency: 'FINRA',
      severity: 'high',
      summary: 'Requires firms to supervise all business-related communications of associated persons.'
    });
    flaggedSnippets.push({
      text: content.slice(0, 140),
      riskReason: 'Attempts to redirect regulated business discussion to personal unarchived messaging application.',
      riskLevel: 'violation'
    });
  }

  // 2. Insider Trading / MNPI (SEC Rule 10b-5)
  if (lower.includes('before the earnings call') || lower.includes('board meeting tomorrow') || lower.includes('acquisition is signed') || lower.includes('fda approval next week') || lower.includes('keep this quiet') || lower.includes('non-public') || lower.includes('mnpi') || lower.includes('do not put this in writing')) {
    severity = 'critical';
    riskScore = Math.max(riskScore, 95);
    domain = 'SEC';
    category = 'Material Non-Public Information (MNPI) / Insider Trading';
    intentAssessment = 'intentional';
    regulations.push({
      code: 'SEC Rule 10b-5',
      title: 'Employment of Manipulative and Deceptive Practices',
      agency: 'SEC',
      severity: 'critical',
      summary: 'Unlawful to trade on or tip material non-public information in breach of a fiduciary or confidentiality obligation.'
    });
    flaggedSnippets.push({
      text: content.slice(0, 160),
      riskReason: 'Discussion references confidential corporate milestones prior to public disclosure with trading encouragement.',
      riskLevel: 'critical'
    });
  }

  // 3. FINRA Promissory / Guaranteed Returns (FINRA Rule 2210)
  if (lower.includes('guaranteed 25%') || lower.includes('guaranteed return') || lower.includes('cannot lose') || lower.includes('risk-free return') || lower.includes('100% safe investment') || lower.includes('no downside')) {
    severity = 'high';
    riskScore = Math.max(riskScore, 88);
    domain = 'FINRA';
    category = 'Misleading Marketing & Promissory Claims';
    intentAssessment = 'negligent';
    regulations.push({
      code: 'FINRA Rule 2210(d)(1)',
      title: 'Communications with the Public - Fair and Balanced Standards',
      agency: 'FINRA',
      severity: 'high',
      summary: 'Prohibits any false, exaggerated, unwarranted, promissory or misleading statement or claim regarding investment outcomes.'
    });
    flaggedSnippets.push({
      text: content.slice(0, 140),
      riskReason: 'Unqualified promissory guarantee of performance without required risk disclosures.',
      riskLevel: 'violation'
    });
  }

  // 4. HIPAA PHI Disclosure (45 CFR § 164.502 / § 164.312)
  const ssnPattern = /\b\d{3}-\d{2}-\d{4}\b/;
  const mrnPattern = /\b(MRN|patient ID|chart #|dob|ssn)\b/i;
  const healthDiagnosisPattern = /\b(biopsy|oncology|hiv|stage 4|psychiatric|chemotherapy|schizophrenia|bipolar|covid|prescribed|dosage)\b/i;

  if (ssnPattern.test(content) || (mrnPattern.test(content) && healthDiagnosisPattern.test(content)) || lower.includes('patient records') || lower.includes('unencrypted ehr') || lower.includes('patient named')) {
    severity = 'critical';
    riskScore = Math.max(riskScore, 92);
    domain = 'HIPAA';
    category = 'Protected Health Information (PHI) Unauthorized Exposure';
    intentAssessment = 'negligent';
    regulations.push({
      code: '45 CFR § 164.502(a)',
      title: 'HIPAA Privacy Rule - General Rules for Uses and Disclosures of PHI',
      agency: 'HIPAA',
      severity: 'critical',
      summary: 'A covered entity may not use or disclose protected health information, except as permitted or required by this subpart.'
    });
    regulations.push({
      code: '45 CFR § 164.312(e)(1)',
      title: 'HIPAA Security Rule - Transmission Security',
      agency: 'HIPAA',
      severity: 'high',
      summary: 'Requires technical security measures to guard against unauthorized access to electronic PHI transmitted over an electronic communications network.'
    });
    flaggedSnippets.push({
      text: content.slice(0, 180),
      riskReason: 'Contains identifiable patient health data and diagnostics transmitted over non-secured standard communications channel.',
      riskLevel: 'critical'
    });
  }

  // 5. Financial Structuring / AML (FINRA 3310 / BSA)
  if (lower.includes('under 10,000') || lower.includes('under $10,000') || lower.includes('split the wire') || lower.includes('avoid the ctr') || lower.includes('smurf')) {
    severity = 'critical';
    riskScore = Math.max(riskScore, 94);
    domain = 'FINRA';
    category = 'Suspicious Activity / Anti-Money Laundering Structuring';
    intentAssessment = 'intentional';
    regulations.push({
      code: 'FINRA Rule 3310 & 31 U.S.C. § 5324',
      title: 'Anti-Money Laundering Compliance Program & Anti-Structuring',
      agency: 'FINRA',
      severity: 'critical',
      summary: 'Prohibits structuring financial transactions for the purpose of evading Currency Transaction Reporting (CTR) requirements.'
    });
    flaggedSnippets.push({
      text: content.slice(0, 160),
      riskReason: 'Language indicates an active effort to break transaction amounts below mandatory reporting thresholds.',
      riskLevel: 'critical'
    });
  }

  const isViolation = severity !== 'clean';

  return {
    isViolation,
    severity,
    riskScore: isViolation ? riskScore : 5,
    domain: isViolation ? domain : 'CLEAN',
    category,
    regulationsViolated: regulations,
    flaggedSnippets: flaggedSnippets.length > 0 ? flaggedSnippets : [],
    summary: isViolation
      ? `Automated surveillance identified ${category} under ${domain} guidelines.`
      : 'No regulatory violations detected. Content complies with standard surveillance policies.',
    intentAssessment,
    remediationAction: isViolation
      ? (domain === 'HIPAA'
          ? 'Quarantine communication immediately. Initiate HIPAA Breach Risk Assessment (45 CFR § 164.402) and notify Chief Privacy Officer.'
          : domain === 'SEC'
          ? 'Place on immediate supervisory hold. Escalate to Chief Compliance Officer (CCO) and preserve original metadata for SEC Rule 17a-4 audit.'
          : 'Issue supervisory warning to registered representative. Request immediate trade justification or retraction.')
      : 'No corrective action required. Routine surveillance archive maintained.',
    supervisoryChecklist: isViolation
      ? [
          'Verify sender/recipient compliance registration status',
          'Quarantine item from external or cross-departmental delivery',
          'Conduct 1-on-1 supervisory interview with flagged employee within 24 hours',
          'Document findings in quarterly Form 17a-4 / HIPAA Compliance Log'
        ]
      : ['Log item in continuous surveillance audit archive']
  };
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    geminiEnabled: !!ai,
    engine: ai ? 'gemini-3.8-flash' : 'rule-engine-fallback'
  });
});

// Primary AI Compliance Scan Endpoint
app.post('/api/compliance/scan', async (req, res) => {
  try {
    const {
      content,
      type = 'communication',
      channel = 'Email',
      sender = 'Unknown Sender',
      recipient = 'Unknown Recipient',
      metadata = {}
    } = req.body;

    if (!content || typeof content !== 'string') {
      return res.status(400).json({ error: 'Missing or invalid "content" in request body.' });
    }

    if (!ai) {
      // Fallback rule-based execution
      const fallback = runFallbackAnalysis(content, type, channel);
      return res.json({
        ...fallback,
        aiEngine: 'rule-engine-fallback',
        analyzedAt: new Date().toISOString()
      });
    }

    const prompt = `You are AegisComply, an elite regulatory compliance surveillance AI specializing in:
1. SEC (Securities and Exchange Commission): SEC Rule 10b-5 (insider trading, MNPI), SEC Rule 17a-4 (unapproved off-channel comms like WhatsApp/Signal/Telegram), Regulation Best Interest (Reg BI), Regulation Fair Disclosure (Reg FD), Investment Advisers Act Rule 206(4)-1.
2. FINRA (Financial Industry Regulatory Authority): FINRA Rule 2210 (Communications with Public: promissory claims, guaranteed returns, unbalanced statements), FINRA Rule 2010 (Commercial honor), FINRA Rule 3110 (Supervision), FINRA Rule 3310 (AML & structuring), FINRA Rule 5270 (Front-running).
3. HIPAA (Health Insurance Portability and Accountability Act): 45 CFR § 164.502 (Privacy Rule - unauthorized disclosure of PHI: names, patient IDs, MRN, medical diagnoses, treatment, lab results), 45 CFR § 164.502(b) (Minimum Necessary rule), 45 CFR § 164.312 (Security Rule - unencrypted ePHI transmission).

Analyze this ${type} carefully:
Channel: ${channel}
Sender: ${sender}
Recipient: ${recipient}
Metadata: ${JSON.stringify(metadata)}

Content to evaluate:
"""
${content}
"""

Determine if there is any violation, risk, or compliance breach.
Output must be structured JSON matching the provided schema.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are an authoritative regulatory compliance officer and auditor. Inspect texts and transactions with zero hallucination. If text is completely routine and compliant, clearly mark isViolation: false, severity: "clean", and riskScore under 15.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isViolation: { type: Type.BOOLEAN, description: 'True if any regulatory violation or actionable compliance risk exists' },
            severity: {
              type: Type.STRING,
              description: 'clean, low, medium, high, or critical'
            },
            riskScore: { type: Type.INTEGER, description: '0 to 100 risk score' },
            domain: {
              type: Type.STRING,
              description: 'SEC, FINRA, HIPAA, CROSS_REGULATORY, or CLEAN'
            },
            category: { type: Type.STRING, description: 'Primary violation classification category' },
            regulationsViolated: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  code: { type: Type.STRING, description: 'E.g. SEC Rule 10b-5, FINRA Rule 2210(d)(1), 45 CFR § 164.502' },
                  title: { type: Type.STRING, description: 'Official title of regulation' },
                  agency: { type: Type.STRING, description: 'SEC, FINRA, HIPAA, HHS, or DOJ' },
                  severity: { type: Type.STRING, description: 'low, medium, high, or critical' },
                  summary: { type: Type.STRING, description: 'Brief breakdown of how this was violated' }
                },
                required: ['code', 'title', 'agency', 'severity', 'summary']
              }
            },
            flaggedSnippets: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  text: { type: Type.STRING, description: 'Exact quote or phrase from the content' },
                  riskReason: { type: Type.STRING, description: 'Why this excerpt constitutes a risk or breach' },
                  riskLevel: { type: Type.STRING, description: 'warning, violation, or critical' }
                },
                required: ['text', 'riskReason', 'riskLevel']
              }
            },
            summary: { type: Type.STRING, description: 'Clear 2-3 sentence executive compliance summary' },
            intentAssessment: {
              type: Type.STRING,
              description: 'intentional, negligent, inadvertent, or benign'
            },
            remediationAction: { type: Type.STRING, description: 'Concrete immediate supervisory action required' },
            supervisoryChecklist: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Checklist items for the compliance officer'
            }
          },
          required: [
            'isViolation',
            'severity',
            'riskScore',
            'domain',
            'category',
            'regulationsViolated',
            'flaggedSnippets',
            'summary',
            'intentAssessment',
            'remediationAction',
            'supervisoryChecklist'
          ]
        }
      }
    });

    const rawText = response.text || '{}';
    const parsed = JSON.parse(rawText);

    res.json({
      ...parsed,
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: new Date().toISOString()
    });
  } catch (error: any) {
    console.error('Gemini compliance scan error:', error);
    // Graceful fallback so app stays fully operational
    const fallback = runFallbackAnalysis(req.body.content || '', req.body.type || 'communication', req.body.channel || 'Email');
    res.json({
      ...fallback,
      aiEngine: 'rule-engine-fallback',
      analyzedAt: new Date().toISOString(),
      fallbackNotice: 'AI scanned via local compliance rules engine.'
    });
  }
});

// Formal Regulatory Audit Memorandum Generator
app.post('/api/compliance/generate-report', async (req, res) => {
  try {
    const { incidents, filterSummary = 'All Active Regulatory Surveillance' } = req.body;

    if (!incidents || !Array.isArray(incidents) || incidents.length === 0) {
      return res.status(400).json({ error: 'No incident list provided.' });
    }

    if (!ai) {
      return res.json({
        reportTitle: `Regulatory Surveillance Supervisory Audit Memorandum`,
        generatedAt: new Date().toISOString(),
        auditorName: 'Automated Surveillance System (AegisComply)',
        executiveSummary: `Surveillance audit report covering ${incidents.length} flagged events across SEC, FINRA, and HIPAA surveillance perimeters.`,
        regulatorBreakdown: {
          SEC: incidents.filter((i: any) => i.domain === 'SEC').length,
          FINRA: incidents.filter((i: any) => i.domain === 'FINRA').length,
          HIPAA: incidents.filter((i: any) => i.domain === 'HIPAA').length
        },
        findings: incidents.map((i: any) => ({
          id: i.id,
          category: i.category,
          severity: i.severity,
          action: i.remediationAction
        })),
        regulatoryDisclosureRecommendation: 'Conduct formal internal review of flagged incidents within 5 business days.'
      });
    }

    const prompt = `Generate a formal Supervisory Compliance Audit Memorandum for the Chief Compliance Officer (CCO) and Internal Audit Committee.
Context:
Surveillance Perimeter: ${filterSummary}
Flagged Incidents: ${JSON.stringify(incidents.slice(0, 15))}

Draft a structured, professional audit memo detailing SEC Rule 17a-4/10b-5, FINRA Rule 2210/3110/3310, and HIPAA 45 CFR § 164.502 risk exposures, systematic patterns, and required regulatory filings (e.g., Form U4 disclosure, SAR, or HHS OCR breach report).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: 'You are a veteran regulatory compliance attorney drafting a formal audit memorandum.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            reportTitle: { type: Type.STRING },
            referenceNumber: { type: Type.STRING },
            generatedAt: { type: Type.STRING },
            executiveSummary: { type: Type.STRING },
            criticalExposures: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            systemicPatternsIdentified: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            regulatoryFilingObligations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  agency: { type: Type.STRING },
                  obligation: { type: Type.STRING },
                  deadline: { type: Type.STRING },
                  mandatory: { type: Type.BOOLEAN }
                },
                required: ['agency', 'obligation', 'deadline', 'mandatory']
              }
            },
            correctiveActionPlan: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            supervisorySignOff: {
              type: Type.OBJECT,
              properties: {
                role: { type: Type.STRING },
                status: { type: Type.STRING },
                recommendedRetentionYears: { type: Type.INTEGER }
              },
              required: ['role', 'status', 'recommendedRetentionYears']
            }
          },
          required: [
            'reportTitle',
            'referenceNumber',
            'generatedAt',
            'executiveSummary',
            'criticalExposures',
            'systemicPatternsIdentified',
            'regulatoryFilingObligations',
            'correctiveActionPlan',
            'supervisorySignOff'
          ]
        }
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('Report generation error:', error);
    res.status(500).json({ error: error.message || 'Failed to generate audit report' });
  }
});

// Mount Vite or serve static
if (process.env.NODE_ENV !== 'production') {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

app.listen(PORT, '0.0.0.0', () => {
  console.log(`AegisComply Server running on port ${PORT}`);
});
