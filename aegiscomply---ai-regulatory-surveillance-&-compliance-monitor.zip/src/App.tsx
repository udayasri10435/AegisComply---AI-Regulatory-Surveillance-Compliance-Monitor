import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Header } from './components/Header';
import { MetricsBar } from './components/MetricsBar';
import { StreamView } from './components/StreamView';
import { IncidentDetailModal } from './components/IncidentDetailModal';
import { ScannerSandbox } from './components/ScannerSandbox';
import { PolicyRulesView } from './components/PolicyRulesView';
import { AuditReportView } from './components/AuditReportView';
import { 
  SurveillanceEvent, 
  SurveillanceStats, 
  CompliancePolicyRule, 
  IncidentStatus, 
  RegulatoryAgency 
} from './types/compliance';
import { 
  INITIAL_SURVEILLANCE_EVENTS, 
  INITIAL_POLICY_RULES, 
  SIMULATION_STREAM_POOL 
} from './data/mockComplianceData';
import { scanComplianceItem, checkServerHealth } from './services/complianceApi';

export default function App() {
  const [events, setEvents] = useState<SurveillanceEvent[]>(INITIAL_SURVEILLANCE_EVENTS);
  const [rules, setRules] = useState<CompliancePolicyRule[]>(INITIAL_POLICY_RULES);
  const [activeTab, setActiveTab] = useState<'stream' | 'sandbox' | 'policies' | 'audit_memo'>('stream');
  const [filterAgency, setFilterAgency] = useState<RegulatoryAgency | 'ALL'>('ALL');
  
  // Streaming state
  const [isStreaming, setIsStreaming] = useState<boolean>(true);
  const [streamSpeed, setStreamSpeed] = useState<number>(1);
  const [selectedEvent, setSelectedEvent] = useState<SurveillanceEvent | null>(null);
  
  const [serverStatus, setServerStatus] = useState<{ status: string; geminiEnabled: boolean; engine: string }>({
    status: 'checking',
    geminiEnabled: true,
    engine: 'gemini-3.8-flash'
  });

  const poolIndexRef = useRef(0);

  // Check backend server health on mount
  useEffect(() => {
    checkServerHealth().then(status => {
      setServerStatus(status);
    });
  }, []);

  // Compute live surveillance statistics
  const stats: SurveillanceStats = useMemo(() => {
    let totalViolations = 0;
    let criticalAlerts = 0;
    let secViolations = 0;
    let finraViolations = 0;
    let hipaaViolations = 0;
    let openIncidents = 0;
    let quarantinedItems = 0;

    events.forEach(e => {
      if (e.analysis?.isViolation) {
        totalViolations++;
        if (e.analysis.severity === 'critical') criticalAlerts++;
        if (e.analysis.domain === 'SEC') secViolations++;
        if (e.analysis.domain === 'FINRA') finraViolations++;
        if (e.analysis.domain === 'HIPAA') hipaaViolations++;
        if (e.status !== 'remediated' && e.status !== 'false_positive') openIncidents++;
      }
      if (e.status === 'quarantined') quarantinedItems++;
    });

    return {
      totalScanned: events.length,
      totalViolations,
      criticalAlerts,
      secViolations,
      finraViolations,
      hipaaViolations,
      openIncidents,
      avgScanLatencyMs: 142,
      quarantinedItems
    };
  }, [events]);

  // Ingest an event programmatically
  const ingestEvent = async (template: typeof SIMULATION_STREAM_POOL[0]) => {
    const eventId = `EVT-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const timestamp = new Date().toISOString();

    try {
      const analysis = await scanComplianceItem({
        content: template.content,
        type: template.type,
        channel: template.channel,
        sender: template.sender,
        recipient: template.recipient,
        metadata: template.metadata
      });

      const newEvent: SurveillanceEvent = {
        id: eventId,
        timestamp,
        type: template.type,
        channel: template.channel,
        sender: template.sender,
        senderRole: template.senderRole,
        senderDepartment: template.senderDepartment,
        recipient: template.recipient,
        recipientRole: template.recipientRole,
        subjectOrIdentifier: template.subjectOrIdentifier,
        content: template.content,
        metadata: template.metadata,
        status: analysis.severity === 'critical' ? 'quarantined' : analysis.isViolation ? 'open' : 'remediated',
        quarantinedAt: analysis.severity === 'critical' ? timestamp : undefined,
        analysis
      };

      setEvents(prev => [newEvent, ...prev]);
    } catch (err) {
      console.error('Error during automated event ingestion scan:', err);
    }
  };

  // Continuous background simulation interval
  useEffect(() => {
    if (!isStreaming) return;

    const intervalTime = Math.max(3000, 10000 / streamSpeed);

    const timer = setInterval(() => {
      const pool = SIMULATION_STREAM_POOL;
      const current = pool[poolIndexRef.current % pool.length];
      poolIndexRef.current += 1;
      ingestEvent(current);
    }, intervalTime);

    return () => clearInterval(timer);
  }, [isStreaming, streamSpeed]);

  const handleSimulateManual = () => {
    const pool = SIMULATION_STREAM_POOL;
    const current = pool[poolIndexRef.current % pool.length];
    poolIndexRef.current += 1;
    ingestEvent(current);
  };

  const handleUpdateStatus = (id: string, status: IncidentStatus) => {
    setEvents(prev => prev.map(e => {
      if (e.id === id) {
        return {
          ...e,
          status,
          quarantinedAt: status === 'quarantined' ? (e.quarantinedAt || new Date().toISOString()) : e.quarantinedAt,
          resolvedAt: (status === 'remediated' || status === 'false_positive') ? new Date().toISOString() : e.resolvedAt
        };
      }
      return e;
    }));

    if (selectedEvent && selectedEvent.id === id) {
      setSelectedEvent(prev => prev ? { ...prev, status } : null);
    }
  };

  const handleToggleRule = (id: string) => {
    setRules(prev => prev.map(r => r.id === id ? { ...r, enabled: !r.enabled } : r));
  };

  const handleAddRule = (newRule: CompliancePolicyRule) => {
    setRules(prev => [newRule, ...prev]);
  };

  const handleAddEventFromSandbox = (newEvent: SurveillanceEvent) => {
    setEvents(prev => [newEvent, ...prev]);
  };

  const handleFilterByDomain = (domain: string) => {
    setFilterAgency(domain as RegulatoryAgency);
    setActiveTab('stream');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans'] antialiased selection:bg-cyan-500/20 selection:text-cyan-200">
      
      {/* Top Application Bar */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isStreaming={isStreaming}
        setIsStreaming={setIsStreaming}
        streamSpeed={streamSpeed}
        setStreamSpeed={setStreamSpeed}
        serverStatus={serverStatus}
        quarantinedCount={stats.quarantinedItems}
      />

      {/* Metrics Ribbon */}
      <MetricsBar
        stats={stats}
        onFilterByDomain={handleFilterByDomain}
      />

      {/* Main Workspace Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'stream' && (
          <StreamView
            events={events}
            onSelectEvent={setSelectedEvent}
            onUpdateStatus={handleUpdateStatus}
            onSimulateEvent={handleSimulateManual}
            filterAgency={filterAgency}
            setFilterAgency={setFilterAgency}
          />
        )}

        {activeTab === 'sandbox' && (
          <ScannerSandbox
            onAddEventToStream={handleAddEventFromSandbox}
          />
        )}

        {activeTab === 'policies' && (
          <PolicyRulesView
            rules={rules}
            onToggleRule={handleToggleRule}
            onAddRule={handleAddRule}
          />
        )}

        {activeTab === 'audit_memo' && (
          <AuditReportView
            events={events}
          />
        )}
      </main>

      {/* Deep Incident Inspection Modal */}
      {selectedEvent && (
        <IncidentDetailModal
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
          onUpdateStatus={handleUpdateStatus}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950/80 py-4 px-4 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">AegisComply</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>SEC Rule 17a-4 Books & Records</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>FINRA Rule 2210 / 3110 / 3310</span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span>HIPAA 45 CFR § 164 Privacy & Security</span>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            Immutable Audit Trail Active · 7-Year WORM Storage Compliant
          </div>
        </div>
      </footer>
    </div>
  );
}
