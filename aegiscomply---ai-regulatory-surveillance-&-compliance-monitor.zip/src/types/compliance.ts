export type RegulatoryAgency = 'SEC' | 'FINRA' | 'HIPAA' | 'CROSS_REGULATORY' | 'CLEAN';

export type ViolationSeverity = 'clean' | 'low' | 'medium' | 'high' | 'critical';

export type EventType = 'communication' | 'transaction';

export type CommunicationChannel = 
  | 'Email (Exchange)'
  | 'Bloomberg Chat'
  | 'Microsoft Teams'
  | 'Slack'
  | 'WhatsApp (Off-Channel)'
  | 'Signal (Off-Channel)'
  | 'SMS / iMessage'
  | 'EHR / Clinical Notes'
  | 'Patient Portal Msg'
  | 'Billing EDI Stream'
  | 'Broker Order Route'
  | 'Fedwire / Swift Transfer';

export interface RegulationViolation {
  code: string;
  title: string;
  agency: RegulatoryAgency;
  severity: ViolationSeverity;
  summary: string;
}

export interface FlaggedSnippet {
  text: string;
  startIndex?: number;
  endIndex?: number;
  riskReason: string;
  riskLevel: 'warning' | 'violation' | 'critical';
}

export interface ComplianceAnalysis {
  isViolation: boolean;
  severity: ViolationSeverity;
  riskScore: number; // 0 to 100
  domain: RegulatoryAgency;
  category: string;
  regulationsViolated: RegulationViolation[];
  flaggedSnippets: FlaggedSnippet[];
  summary: string;
  intentAssessment: 'intentional' | 'negligent' | 'inadvertent' | 'benign';
  remediationAction: string;
  supervisoryChecklist: string[];
  aiEngine?: string;
  analyzedAt?: string;
}

export type IncidentStatus = 'open' | 'investigating' | 'quarantined' | 'escalated' | 'remediated' | 'false_positive';

export interface SurveillanceEvent {
  id: string;
  timestamp: string;
  type: EventType;
  channel: CommunicationChannel;
  sender: string;
  senderRole: string;
  senderDepartment: string;
  recipient: string;
  recipientRole?: string;
  subjectOrIdentifier: string;
  content: string;
  metadata?: Record<string, any>;
  analysis?: ComplianceAnalysis;
  status: IncidentStatus;
  assignedAuditor?: string;
  auditNotes?: string[];
  quarantinedAt?: string;
  resolvedAt?: string;
}

export interface SurveillanceStats {
  totalScanned: number;
  totalViolations: number;
  criticalAlerts: number;
  secViolations: number;
  finraViolations: number;
  hipaaViolations: number;
  openIncidents: number;
  avgScanLatencyMs: number;
  quarantinedItems: number;
}

export interface CompliancePolicyRule {
  id: string;
  name: string;
  agency: RegulatoryAgency;
  ruleCode: string;
  description: string;
  enabled: boolean;
  severity: ViolationSeverity;
  actionOnTrigger: 'quarantine' | 'alert_cco' | 'flag_supervision' | 'log_only';
  detectionType: 'ai_semantic' | 'regex_pattern' | 'hybrid';
}
