import React, { useState } from 'react';
import { 
  Sparkles, 
  ShieldAlert, 
  Send, 
  Copy, 
  Check, 
  AlertTriangle, 
  FileCheck, 
  Cpu, 
  Layers, 
  PlusCircle,
  FileWarning
} from 'lucide-react';
import { ComplianceAnalysis, CommunicationChannel, SurveillanceEvent } from '../types/compliance';
import { PRESET_SCAN_TEMPLATES } from '../data/mockComplianceData';
import { scanComplianceItem } from '../services/complianceApi';

interface ScannerSandboxProps {
  onAddEventToStream: (event: SurveillanceEvent) => void;
}

export const ScannerSandbox: React.FC<ScannerSandboxProps> = ({ onAddEventToStream }) => {
  const [content, setContent] = useState(PRESET_SCAN_TEMPLATES[0].content);
  const [channel, setChannel] = useState<CommunicationChannel>(PRESET_SCAN_TEMPLATES[0].channel);
  const [sender, setSender] = useState(PRESET_SCAN_TEMPLATES[0].sender);
  const [senderRole, setSenderRole] = useState(PRESET_SCAN_TEMPLATES[0].senderRole);
  const [recipient, setRecipient] = useState(PRESET_SCAN_TEMPLATES[0].recipient);
  const [type, setType] = useState<'communication' | 'transaction'>('communication');
  
  const [isScanning, setIsScanning] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<ComplianceAnalysis | null>(null);
  const [copied, setCopied] = useState(false);
  const [addedToStream, setAddedToStream] = useState(false);

  const handleSelectPreset = (preset: typeof PRESET_SCAN_TEMPLATES[0]) => {
    setContent(preset.content);
    setChannel(preset.channel);
    setSender(preset.sender);
    setSenderRole(preset.senderRole);
    setRecipient(preset.recipient);
    setAnalysisResult(null);
    setAddedToStream(false);
  };

  const handleRunScan = async () => {
    if (!content.trim()) return;
    setIsScanning(true);
    setAnalysisResult(null);
    setAddedToStream(false);

    try {
      const result = await scanComplianceItem({
        content,
        type,
        channel,
        sender,
        recipient,
        metadata: {
          scannedInSandbox: true,
          timestamp: new Date().toISOString()
        }
      });
      setAnalysisResult(result);
    } catch (err) {
      console.error('Scan error:', err);
    } finally {
      setIsScanning(false);
    }
  };

  const handleAddCurrentToStream = () => {
    if (!analysisResult) return;
    
    const newEvent: SurveillanceEvent = {
      id: `EVT-MANUAL-${Date.now().toString().slice(-4)}`,
      timestamp: new Date().toISOString(),
      type,
      channel,
      sender,
      senderRole,
      senderDepartment: 'Custom Ingestion / Sandbox',
      recipient,
      subjectOrIdentifier: `Manual Sandbox Scan - ${analysisResult.category}`,
      content,
      status: analysisResult.isViolation ? 'open' : 'remediated',
      analysis: analysisResult
    };

    onAddEventToStream(newEvent);
    setAddedToStream(true);
    setTimeout(() => setAddedToStream(false), 3000);
  };

  const handleCopyResult = () => {
    if (!analysisResult) return;
    navigator.clipboard.writeText(JSON.stringify(analysisResult, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Intro Header */}
      <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-cyan-400" />
              <span>Interactive AI Compliance Scanner</span>
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Test any custom message, chat transcript, trade memorandum, or EHR payload against SEC, FINRA, and HIPAA regulations using Gemini 3.8.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-900/60 px-3 py-1.5 rounded-lg">
            <Cpu className="w-4 h-4" />
            <span>Multi-Regime Semantic Parser</span>
          </div>
        </div>

        {/* Preset Selector Carousel */}
        <div className="mt-4 pt-4 border-t border-slate-800">
          <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-2">
            Load Regulatory Scenario Preset:
          </span>
          <div className="flex gap-2 overflow-x-auto pb-1">
            {PRESET_SCAN_TEMPLATES.map((preset, idx) => {
              const badgeColor = 
                preset.agency === 'SEC' ? 'border-cyan-800 text-cyan-400' :
                preset.agency === 'FINRA' ? 'border-indigo-800 text-indigo-400' :
                'border-emerald-800 text-emerald-400';

              return (
                <button
                  key={idx}
                  onClick={() => handleSelectPreset(preset)}
                  className="px-3 py-2 bg-slate-950 hover:bg-slate-800 border border-slate-800 rounded-lg text-left transition-all hover:border-slate-700 min-w-[220px] max-w-[260px] flex-shrink-0"
                >
                  <div className="flex items-center justify-between text-[10px] font-mono mb-1">
                    <span className={`px-1.5 py-0.5 rounded border ${badgeColor}`}>
                      {preset.agency}
                    </span>
                    <span className="text-slate-500">{preset.channel}</span>
                  </div>
                  <div className="text-xs font-medium text-slate-200 line-clamp-1">
                    {preset.title}
                  </div>
                  <div className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                    {preset.description}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Sandbox Grid: Input Form on Left, AI Output on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Form: Payload & Metadata (7 cols) */}
        <div className="lg:col-span-7 bg-slate-950/70 border border-slate-800 p-5 rounded-xl space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Ingestion Type
              </label>
              <select
                value={type}
                onChange={e => setType(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="communication">Communication (Email/Chat/SMS)</option>
                <option value="transaction">Financial / EHR Transaction</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Channel / Transport
              </label>
              <select
                value={channel}
                onChange={e => setChannel(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              >
                <option value="Email (Exchange)">Email (Exchange)</option>
                <option value="Bloomberg Chat">Bloomberg Chat</option>
                <option value="Microsoft Teams">Microsoft Teams</option>
                <option value="Slack">Slack</option>
                <option value="WhatsApp (Off-Channel)">WhatsApp (Off-Channel)</option>
                <option value="Signal (Off-Channel)">Signal (Off-Channel)</option>
                <option value="SMS / iMessage">SMS / iMessage</option>
                <option value="EHR / Clinical Notes">EHR / Clinical Notes</option>
                <option value="Fedwire / Swift Transfer">Fedwire / Swift Transfer</option>
                <option value="Broker Order Route">Broker Order Route</option>
              </select>
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Sender Role
              </label>
              <input
                type="text"
                value={senderRole}
                onChange={e => setSenderRole(e.target.value)}
                placeholder="e.g. Registered Rep"
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Sender Identifier / Email
              </label>
              <input
                type="text"
                value={sender}
                onChange={e => setSender(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>
            <div>
              <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Recipient / Audience
              </label>
              <input
                type="text"
                value={recipient}
                onChange={e => setRecipient(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                Raw Content / Payload to Inspect
              </label>
              <span className="text-[11px] font-mono text-slate-500">
                {content.length} characters
              </span>
            </div>
            <textarea
              rows={8}
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="Paste email text, chat dialogue, wire instruction, or clinical consultation note..."
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 font-mono focus:outline-none focus:border-blue-500 leading-relaxed resize-y"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => setContent('')}
              className="px-3 py-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
            >
              Clear Payload
            </button>

            <button
              onClick={handleRunScan}
              disabled={isScanning || !content.trim()}
              className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-medium text-xs rounded-lg shadow-lg shadow-blue-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {isScanning ? (
                <>
                  <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Analyzing Regulatory Vectors...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Execute Gemini Compliance Scan</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Panel: Structured AI Verdict (5 cols) */}
        <div className="lg:col-span-5 bg-slate-950/70 border border-slate-800 p-5 rounded-xl flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-2">
              <FileCheck className="w-4 h-4 text-cyan-400" />
              <span>Surveillance Verdict & Assessment</span>
            </h3>
            {analysisResult && (
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyResult}
                  className="text-slate-400 hover:text-white p-1 rounded hover:bg-slate-800 transition-colors"
                  title="Copy JSON Analysis"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            )}
          </div>

          {!analysisResult && !isScanning && (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-500">
              <ShieldAlert className="w-10 h-10 text-slate-700 mb-3" />
              <p className="text-xs text-slate-400">No active audit result</p>
              <p className="text-[11px] text-slate-600 mt-1 max-w-xs">
                Select a preset template or enter custom text, then click "Execute Gemini Compliance Scan"
              </p>
            </div>
          )}

          {isScanning && (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 text-slate-400 space-y-3">
              <div className="w-8 h-8 border-2 border-cyan-500/20 border-t-cyan-400 rounded-full animate-spin" />
              <p className="text-xs font-mono">Running deep semantic evaluation against SEC, FINRA, and HIPAA rules...</p>
            </div>
          )}

          {analysisResult && (
            <div className="space-y-4 flex-1 overflow-y-auto pr-1">
              {/* Verdict Banner */}
              <div className={`p-4 rounded-lg border ${
                analysisResult.severity === 'critical' ? 'bg-rose-950/30 border-rose-900/60 text-rose-300' :
                analysisResult.severity === 'high' ? 'bg-amber-950/30 border-amber-900/60 text-amber-300' :
                analysisResult.severity === 'medium' ? 'bg-yellow-950/30 border-yellow-900/60 text-yellow-300' :
                'bg-emerald-950/30 border-emerald-900/60 text-emerald-300'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono uppercase font-bold tracking-wide">
                    {analysisResult.isViolation ? `${analysisResult.severity} Violation` : 'Compliant'}
                  </span>
                  <span className="text-xs font-mono font-bold">
                    Risk Score: {analysisResult.riskScore}/100
                  </span>
                </div>
                <div className="text-sm font-semibold text-white mt-1">
                  {analysisResult.category}
                </div>
              </div>

              {/* Statutory Rules Violated */}
              {analysisResult.regulationsViolated?.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block">
                    Statutory Regulatory Citations
                  </span>
                  <div className="space-y-1.5">
                    {analysisResult.regulationsViolated.map((r, i) => (
                      <div key={i} className="p-2.5 bg-slate-900 border border-slate-800 rounded-lg text-xs">
                        <div className="flex items-center justify-between font-mono font-bold text-cyan-400">
                          <span>{r.code}</span>
                          <span className="text-[10px] text-slate-400 font-normal">{r.agency}</span>
                        </div>
                        <div className="text-slate-300 text-xs mt-0.5">{r.title}</div>
                        <div className="text-slate-400 text-[11px] mt-1 leading-relaxed">{r.summary}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Redline Snippet Evidence */}
              {analysisResult.flaggedSnippets?.length > 0 && (
                <div className="space-y-1.5">
                  <span className="text-[11px] font-mono text-amber-400 uppercase tracking-wider block">
                    Offending Excerpts
                  </span>
                  <div className="space-y-1.5">
                    {analysisResult.flaggedSnippets.map((s, i) => (
                      <div key={i} className="p-2 bg-amber-950/20 border border-amber-900/40 rounded text-xs">
                        <p className="font-mono text-amber-300 text-[11px]">"{s.text}"</p>
                        <p className="text-slate-400 text-[10px] mt-1">{s.riskReason}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Executive Summary */}
              <div>
                <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                  Compliance Summary
                </span>
                <p className="text-xs text-slate-300 bg-slate-900 p-2.5 rounded border border-slate-800 leading-relaxed">
                  {analysisResult.summary}
                </p>
              </div>

              {/* Remediation Directive */}
              <div>
                <span className="text-[11px] font-mono text-rose-400 uppercase tracking-wider block mb-1">
                  Required Supervisory Remediation
                </span>
                <p className="text-xs text-slate-200 bg-slate-900 p-2.5 rounded border border-slate-800 leading-relaxed">
                  {analysisResult.remediationAction}
                </p>
              </div>

              {/* Stream Ingestion Button */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-mono">
                  Engine: {analysisResult.aiEngine || 'Gemini 3.8'}
                </span>
                <button
                  onClick={handleAddCurrentToStream}
                  disabled={addedToStream}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
                >
                  {addedToStream ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Injected to Stream</span>
                    </>
                  ) : (
                    <>
                      <PlusCircle className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Inject into Live Stream</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
