import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle, 
  Eye, 
  Lock, 
  Flame, 
  ArrowUpDown, 
  PlusCircle, 
  MessageSquare, 
  Send,
  Building,
  Radio
} from 'lucide-react';
import { SurveillanceEvent, RegulatoryAgency, ViolationSeverity, IncidentStatus } from '../types/compliance';

interface StreamViewProps {
  events: SurveillanceEvent[];
  onSelectEvent: (event: SurveillanceEvent) => void;
  onUpdateStatus: (id: string, status: IncidentStatus) => void;
  onSimulateEvent: () => void;
  filterAgency: RegulatoryAgency | 'ALL';
  setFilterAgency: (agency: RegulatoryAgency | 'ALL') => void;
}

export const StreamView: React.FC<StreamViewProps> = ({
  events,
  onSelectEvent,
  onUpdateStatus,
  onSimulateEvent,
  filterAgency,
  setFilterAgency,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<'ALL' | ViolationSeverity>('ALL');
  const [channelFilter, setChannelFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | IncidentStatus>('ALL');

  const filteredEvents = useMemo(() => {
    return events.filter(e => {
      // Agency Filter
      if (filterAgency !== 'ALL') {
        if (filterAgency === 'CLEAN' && e.analysis?.isViolation) return false;
        if (filterAgency !== 'CLEAN' && e.analysis?.domain !== filterAgency) return false;
      }

      // Severity Filter
      if (severityFilter !== 'ALL' && e.analysis?.severity !== severityFilter) {
        return false;
      }

      // Channel Filter
      if (channelFilter !== 'ALL' && !e.channel.toLowerCase().includes(channelFilter.toLowerCase())) {
        return false;
      }

      // Status Filter
      if (statusFilter !== 'ALL' && e.status !== statusFilter) {
        return false;
      }

      // Search Query
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const matchContent = e.content.toLowerCase().includes(query);
        const matchSender = e.sender.toLowerCase().includes(query);
        const matchRecipient = e.recipient.toLowerCase().includes(query);
        const matchDepartment = e.senderDepartment.toLowerCase().includes(query);
        const matchCategory = (e.analysis?.category || '').toLowerCase().includes(query);
        const matchCode = (e.analysis?.regulationsViolated || []).some(r => r.code.toLowerCase().includes(query));

        if (!matchContent && !matchSender && !matchRecipient && !matchDepartment && !matchCategory && !matchCode) {
          return false;
        }
      }

      return true;
    });
  }, [events, filterAgency, severityFilter, channelFilter, statusFilter, searchTerm]);

  return (
    <div className="space-y-4">
      {/* Control Strip: Search & Interactive Filter Buttons */}
      <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl flex flex-col md:flex-row gap-4 justify-between items-stretch md:items-center">
        
        {/* Segmented Agency Filter */}
        <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg overflow-x-auto">
          {(['ALL', 'SEC', 'FINRA', 'HIPAA', 'CLEAN'] as const).map(regime => (
            <button
              key={regime}
              onClick={() => setFilterAgency(regime)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
                filterAgency === regime
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {regime === 'ALL' ? 'All Frameworks' : regime === 'CLEAN' ? 'Compliant Only' : regime}
            </button>
          ))}
        </div>

        {/* Search Input & Manual Simulation */}
        <div className="flex items-center gap-3 flex-1 md:max-w-md">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search content, sender, statutory rule (e.g. 17a-4, MNPI, PHI)..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-9 pr-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-blue-500 font-mono"
            />
          </div>

          <button
            onClick={onSimulateEvent}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors whitespace-nowrap"
            title="Inject simulated inbound communication or transaction"
          >
            <PlusCircle className="w-3.5 h-3.5 text-cyan-400" />
            <span>Simulate Ingest</span>
          </button>
        </div>
      </div>

      {/* Sub-Filters: Severity, Channel & Status */}
      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <div className="flex items-center gap-4 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span>Severity:</span>
            <select
              value={severityFilter}
              onChange={e => setSeverityFilter(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs focus:outline-none"
            >
              <option value="ALL">All Severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="clean">Compliant</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span>Channel:</span>
            <select
              value={channelFilter}
              onChange={e => setChannelFilter(e.target.value)}
              className="bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs focus:outline-none"
            >
              <option value="ALL">All Ingestion Channels</option>
              <option value="email">Email (Exchange)</option>
              <option value="bloomberg">Bloomberg Chat</option>
              <option value="slack">Slack / Teams</option>
              <option value="whatsapp">WhatsApp / Signal</option>
              <option value="ehr">EHR / Clinical Notes</option>
              <option value="wire">Fedwire / Swift</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span>Lifecycle:</span>
            <select
              value={statusFilter}
              onChange={e => setStatusFilter(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 text-slate-200 rounded px-2 py-1 text-xs focus:outline-none"
            >
              <option value="ALL">All Statuses</option>
              <option value="open">Open</option>
              <option value="quarantined">Quarantined</option>
              <option value="escalated">Escalated</option>
              <option value="remediated">Remediated</option>
              <option value="false_positive">False Positive</option>
            </select>
          </div>
        </div>

        <div className="font-mono tabular-nums text-slate-400">
          Showing {filteredEvents.length} of {events.length} surveillance events
        </div>
      </div>

      {/* Surveillance Event Stream List */}
      <div className="bg-slate-950/60 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
        <div className="divide-y divide-slate-800/80">
          {filteredEvents.length === 0 ? (
            <div className="p-12 text-center text-slate-500">
              <ShieldAlert className="w-10 h-10 mx-auto text-slate-600 mb-3" />
              <p className="text-sm font-medium text-slate-400">No surveillance records match current filters</p>
              <p className="text-xs text-slate-600 mt-1">Try resetting the agency, severity, or search query</p>
            </div>
          ) : (
            filteredEvents.map(event => {
              const analysis = event.analysis;
              const isViolation = analysis?.isViolation;
              const severity = analysis?.severity || 'clean';

              const severityBadge = 
                severity === 'critical' ? 'text-rose-400 border-rose-900/60 bg-rose-950/40' :
                severity === 'high' ? 'text-amber-400 border-amber-900/60 bg-amber-950/40' :
                severity === 'medium' ? 'text-yellow-400 border-yellow-900/60 bg-yellow-950/40' :
                'text-emerald-400 border-emerald-900/60 bg-emerald-950/40';

              const domainColor = 
                analysis?.domain === 'SEC' ? 'text-cyan-400' :
                analysis?.domain === 'FINRA' ? 'text-indigo-400' :
                analysis?.domain === 'HIPAA' ? 'text-emerald-400' :
                'text-slate-400';

              return (
                <div
                  key={event.id}
                  className="p-4 hover:bg-slate-900/50 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-4 cursor-pointer group"
                  onClick={() => onSelectEvent(event)}
                >
                  {/* Left Column: Metadata, Sender, Channel & Excerpt */}
                  <div className="flex-1 min-w-0 space-y-1.5">
                    {/* Top Row: Timestamp, Domain, Code & Severity */}
                    <div className="flex items-center gap-2 text-xs flex-wrap">
                      <span className="font-mono text-slate-500 tabular-nums">
                        {new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                      </span>
                      <span aria-hidden="true" className="text-slate-700">·</span>
                      <span className="font-mono font-semibold text-slate-400">
                        {event.channel}
                      </span>
                      <span aria-hidden="true" className="text-slate-700">·</span>
                      <span className={`font-mono font-bold ${domainColor}`}>
                        {analysis?.domain || 'GENERAL'}
                      </span>
                      {analysis?.regulationsViolated?.[0] && (
                        <>
                          <span aria-hidden="true" className="text-slate-700">·</span>
                          <span className="font-mono text-slate-300">
                            {analysis.regulationsViolated[0].code}
                          </span>
                        </>
                      )}
                      <span aria-hidden="true" className="text-slate-700">·</span>
                      <span className={`text-[10px] font-mono uppercase px-1.5 py-0.5 rounded border ${severityBadge}`}>
                        {severity}
                      </span>
                    </div>

                    {/* Middle Row: Sender & Department */}
                    <div className="flex items-center gap-2 text-xs">
                      <span className="font-medium text-slate-200">
                        {event.sender}
                      </span>
                      <span className="text-slate-500 text-[11px]">
                        ({event.senderRole} · {event.senderDepartment})
                      </span>
                      <span className="text-slate-600">→</span>
                      <span className="text-slate-400 text-xs truncate max-w-[200px]">
                        {event.recipient}
                      </span>
                    </div>

                    {/* Bottom Row: Redline Content Snippet */}
                    <p className="text-xs text-slate-300 font-mono line-clamp-2 bg-slate-900/60 p-2 rounded border border-slate-800/80 group-hover:border-slate-700 transition-colors">
                      {event.content}
                    </p>
                  </div>

                  {/* Right Column: Score, Status & Actions */}
                  <div className="flex items-center gap-4 flex-shrink-0 self-end md:self-center">
                    {/* Risk Score */}
                    <div className="text-right">
                      <span className="text-[10px] font-mono text-slate-500 block">RISK SCORE</span>
                      <span className={`font-mono text-base font-bold tabular-nums ${
                        (analysis?.riskScore || 0) >= 80 ? 'text-rose-400' :
                        (analysis?.riskScore || 0) >= 50 ? 'text-amber-400' : 'text-emerald-400'
                      }`}>
                        {analysis?.riskScore || 0}
                      </span>
                    </div>

                    {/* Status Pill */}
                    <div className="text-right min-w-[90px]">
                      <span className="text-[10px] font-mono text-slate-500 block">STATUS</span>
                      <span className={`text-xs font-mono uppercase font-semibold ${
                        event.status === 'quarantined' ? 'text-rose-400' :
                        event.status === 'escalated' ? 'text-amber-400' :
                        event.status === 'remediated' ? 'text-emerald-400' :
                        'text-slate-300'
                      }`}>
                        {event.status}
                      </span>
                    </div>

                    {/* Action Button */}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onSelectEvent(event);
                      }}
                      className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-md text-xs font-medium flex items-center gap-1 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Inspect</span>
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
