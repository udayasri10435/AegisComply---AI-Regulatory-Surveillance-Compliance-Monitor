import React, { useState } from 'react';
import { 
  X, 
  ShieldAlert, 
  AlertTriangle, 
  CheckCircle2, 
  Lock, 
  Share2, 
  User, 
  Building, 
  Clock, 
  FileWarning, 
  CheckSquare, 
  Square,
  Copy,
  ExternalLink,
  Flame,
  ArrowRight
} from 'lucide-react';
import { SurveillanceEvent, IncidentStatus } from '../types/compliance';

interface IncidentDetailModalProps {
  event: SurveillanceEvent | null;
  onClose: () => void;
  onUpdateStatus: (id: string, status: IncidentStatus, note?: string) => void;
}

export const IncidentDetailModal: React.FC<IncidentDetailModalProps> = ({
  event,
  onClose,
  onUpdateStatus,
}) => {
  if (!event) return null;

  const [copied, setCopied] = useState(false);
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});
  const [supervisoryNote, setSupervisoryNote] = useState('');
  const [showNoteInput, setShowNoteInput] = useState(false);

  const analysis = event.analysis;

  const toggleCheck = (index: number) => {
    setCheckedItems(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const handleCopyCitation = () => {
    if (!analysis) return;
    const citation = `[COMPLIANCE INCIDENT ${event.id}]\nDomain: ${analysis.domain}\nSeverity: ${analysis.severity.toUpperCase()}\nRegulations: ${analysis.regulationsViolated.map(r => r.code).join(', ')}\nSummary: ${analysis.summary}\nRemediation: ${analysis.remediationAction}`;
    navigator.clipboard.writeText(citation);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const renderHighlightedContent = () => {
    if (!analysis || !analysis.flaggedSnippets || analysis.flaggedSnippets.length === 0) {
      return <p className="text-slate-300 leading-relaxed font-mono text-sm whitespace-pre-wrap">{event.content}</p>;
    }

    // Highlight snippets in text
    let content = event.content;
    const snippets = analysis.flaggedSnippets;

    return (
      <div className="text-slate-200 text-sm leading-relaxed font-mono whitespace-pre-wrap bg-slate-950 p-4 rounded-lg border border-slate-800">
        {content}
      </div>
    );
  };

  const severityColor = 
    analysis?.severity === 'critical' ? 'text-rose-400 bg-rose-950/40 border-rose-800/80' :
    analysis?.severity === 'high' ? 'text-amber-400 bg-amber-950/40 border-amber-800/80' :
    analysis?.severity === 'medium' ? 'text-yellow-400 bg-yellow-950/40 border-yellow-800/80' :
    'text-emerald-400 bg-emerald-950/40 border-emerald-800/80';

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative bg-slate-900 border border-slate-800 rounded-xl shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-150">
        
        {/* Modal Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg border ${severityColor}`}>
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-semibold text-white tracking-wide">
                  {event.id}
                </span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-xs text-slate-400">{event.channel}</span>
                <span aria-hidden="true" className="text-slate-600">·</span>
                <span className="text-xs font-mono text-slate-400">
                  {new Date(event.timestamp).toLocaleString()}
                </span>
              </div>
              <h2 className="text-base font-bold text-white mt-0.5">
                {analysis?.category || event.subjectOrIdentifier}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyCitation}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-md transition-colors"
              title="Copy incident brief for filing"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'Copied' : 'Copy Citation'}</span>
            </button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* Top Metadata Grid: Sender, Recipient, Severity & Score */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Sender Context */}
            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Sender Profile
              </span>
              <div className="font-medium text-slate-200 text-sm truncate">
                {event.sender}
              </div>
              <div className="text-xs text-slate-400 mt-1 flex items-center gap-1.5">
                <User className="w-3 h-3 text-slate-500" />
                <span>{event.senderRole}</span>
              </div>
              <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-1.5">
                <Building className="w-3 h-3 text-slate-500" />
                <span>{event.senderDepartment}</span>
              </div>
            </div>

            {/* Recipient Context */}
            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg">
              <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                Recipient / Audience
              </span>
              <div className="font-medium text-slate-200 text-sm truncate">
                {event.recipient}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                {event.recipientRole || 'External Destination'}
              </div>
              {event.metadata && (
                <div className="text-[11px] font-mono text-slate-400 mt-1">
                  {Object.entries(event.metadata).map(([k, v]) => `${k}: ${v}`).join(' · ')}
                </div>
              )}
            </div>

            {/* Risk Score & Assessment */}
            <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-lg flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[11px] font-mono text-slate-400 uppercase tracking-wider">
                    Regulatory Risk Score
                  </span>
                  <span className="font-mono text-xs font-bold text-rose-400">
                    {analysis?.riskScore || 0}/100
                  </span>
                </div>
                {/* Progress Gauge */}
                <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-500 ${
                      (analysis?.riskScore || 0) >= 80 ? 'bg-rose-500' :
                      (analysis?.riskScore || 0) >= 50 ? 'bg-amber-500' : 'bg-emerald-500'
                    }`}
                    style={{ width: `${analysis?.riskScore || 0}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-xs mt-3 pt-2 border-t border-slate-800">
                <span className="text-slate-400">Intent Assessment:</span>
                <span className="font-mono uppercase font-semibold text-slate-300">
                  {analysis?.intentAssessment || 'Under Review'}
                </span>
              </div>
            </div>
          </div>

          {/* Section: Raw Message / Transaction Content with Redline */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-2">
                <span>Interception Content Payload</span>
                <span className="text-slate-400 font-normal">({event.channel})</span>
              </h3>
              <span className="text-xs text-slate-400 font-mono">
                Status: <span className="font-semibold text-slate-300 uppercase">{event.status}</span>
              </span>
            </div>
            {renderHighlightedContent()}
          </div>

          {/* Section: Flagged Redline Snippets & Specific Violations */}
          {analysis && analysis.flaggedSnippets && analysis.flaggedSnippets.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-mono uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <FileWarning className="w-3.5 h-3.5" />
                <span>Extracted Redline Evidence Snippets</span>
              </h3>
              <div className="space-y-2">
                {analysis.flaggedSnippets.map((snip, idx) => (
                  <div key={idx} className="p-3 bg-amber-950/20 border border-amber-900/40 rounded-lg">
                    <div className="text-xs font-mono font-medium text-amber-300 bg-amber-950/60 px-2 py-1 rounded inline-block mb-1.5 border border-amber-800/40">
                      "{snip.text}"
                    </div>
                    <div className="text-xs text-slate-300 flex items-start gap-2">
                      <span className="text-amber-500 font-bold">Risk Reason:</span>
                      <span>{snip.riskReason}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section: Statutory Regulatory Violations */}
          {analysis && analysis.regulationsViolated && analysis.regulationsViolated.length > 0 && (
            <div className="space-y-2">
              <h3 className="text-xs font-mono uppercase tracking-wider text-cyan-400 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Statutory Violations & Regulatory Codes</span>
              </h3>
              <div className="grid grid-cols-1 gap-2.5">
                {analysis.regulationsViolated.map((reg, idx) => (
                  <div key={idx} className="p-3 bg-slate-950 border border-slate-800 rounded-lg">
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-cyan-400">
                          {reg.code}
                        </span>
                        <span aria-hidden="true" className="text-slate-600">·</span>
                        <span className="text-xs font-semibold text-slate-300">
                          {reg.title}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {reg.agency}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {reg.summary}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Section: AI Compliance Executive Summary & Remediation */}
          {analysis && (
            <div className="bg-slate-950/90 border border-slate-800 p-4 rounded-lg space-y-3">
              <div>
                <span className="text-xs font-mono uppercase text-slate-400 tracking-wider block mb-1">
                  Surveillance Analysis Summary
                </span>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {analysis.summary}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-xs font-mono uppercase text-rose-400 tracking-wider block mb-1">
                  Mandated Supervisory Remediation
                </span>
                <p className="text-xs font-medium text-slate-200 leading-relaxed bg-slate-900 p-2.5 rounded border border-slate-800">
                  {analysis.remediationAction}
                </p>
              </div>
            </div>
          )}

          {/* Section: Interactive Supervisory Checklist */}
          {analysis && analysis.supervisoryChecklist && (
            <div className="space-y-2">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400 block">
                Compliance Officer Action Checklist
              </span>
              <div className="space-y-1.5 bg-slate-950 p-3 rounded-lg border border-slate-800">
                {analysis.supervisoryChecklist.map((item, idx) => {
                  const isChecked = !!checkedItems[idx];
                  return (
                    <div
                      key={idx}
                      onClick={() => toggleCheck(idx)}
                      className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer hover:text-white p-1 rounded transition-colors"
                    >
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-600 flex-shrink-0" />
                      )}
                      <span className={isChecked ? 'line-through text-slate-400' : ''}>
                        {item}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer Controls */}
        <div className="p-4 border-t border-slate-800 bg-slate-950 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">Current Lifecycle:</span>
            <span className="text-xs font-mono font-bold text-white uppercase px-2 py-0.5 bg-slate-800 rounded">
              {event.status}
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {event.status !== 'quarantined' && (
              <button
                onClick={() => onUpdateStatus(event.id, 'quarantined')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-rose-900/60 hover:bg-rose-800 text-rose-200 border border-rose-700/60 transition-colors"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>Quarantine Payload</span>
              </button>
            )}

            {event.status !== 'escalated' && (
              <button
                onClick={() => onUpdateStatus(event.id, 'escalated')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-amber-900/60 hover:bg-amber-800 text-amber-200 border border-amber-700/60 transition-colors"
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Escalate to CCO / Legal</span>
              </button>
            )}

            {event.status !== 'remediated' && (
              <button
                onClick={() => onUpdateStatus(event.id, 'remediated')}
                className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md bg-emerald-900/60 hover:bg-emerald-800 text-emerald-200 border border-emerald-700/60 transition-colors"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Mark Remediated</span>
              </button>
            )}

            {event.status !== 'false_positive' && (
              <button
                onClick={() => onUpdateStatus(event.id, 'false_positive')}
                className="px-3 py-1.5 text-xs font-medium rounded-md bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
              >
                Dismiss (False Positive)
              </button>
            )}

            <button
              onClick={onClose}
              className="px-3 py-1.5 text-xs font-medium rounded-md bg-slate-800 hover:bg-slate-700 text-white transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
