import React from 'react';
import { ShieldCheck, AlertTriangle, Flame, Lock, Layers, Zap } from 'lucide-react';
import { SurveillanceStats } from '../types/compliance';

interface MetricsBarProps {
  stats: SurveillanceStats;
  onFilterByDomain?: (domain: string) => void;
}

export const MetricsBar: React.FC<MetricsBarProps> = ({ stats, onFilterByDomain }) => {
  const violationRate = stats.totalScanned > 0 
    ? ((stats.totalViolations / stats.totalScanned) * 100).toFixed(1)
    : '0.0';

  return (
    <section className="bg-slate-900/60 border-b border-slate-800/80 py-4 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {/* Total Scanned */}
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Total Scanned</span>
              <Layers className="w-3.5 h-3.5 text-blue-400" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono tabular-nums text-white">
                {stats.totalScanned.toLocaleString()}
              </span>
              <span className="text-[11px] text-slate-400 font-mono">events</span>
            </div>
          </div>

          {/* Violations Intercepted */}
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Violations</span>
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono tabular-nums text-amber-400">
                {stats.totalViolations}
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                ({violationRate}%)
              </span>
            </div>
          </div>

          {/* Critical Escalations */}
          <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col justify-between">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Critical Alerts</span>
              <Flame className="w-3.5 h-3.5 text-rose-500" />
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono tabular-nums text-rose-400">
                {stats.criticalAlerts}
              </span>
              <span className="text-[11px] text-rose-500/80 font-mono">Immediate</span>
            </div>
          </div>

          {/* SEC Violations */}
          <div 
            onClick={() => onFilterByDomain && onFilterByDomain('SEC')}
            className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col justify-between cursor-pointer hover:border-slate-700 transition-colors"
          >
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>SEC Breaches</span>
              <span className="text-[10px] font-mono text-cyan-400">17a-4 / 10b-5</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono tabular-nums text-cyan-400">
                {stats.secViolations}
              </span>
              <span className="text-[11px] text-slate-400 font-mono">Off-channel / MNPI</span>
            </div>
          </div>

          {/* FINRA Violations */}
          <div 
            onClick={() => onFilterByDomain && onFilterByDomain('FINRA')}
            className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col justify-between cursor-pointer hover:border-slate-700 transition-colors"
          >
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>FINRA Breaches</span>
              <span className="text-[10px] font-mono text-indigo-400">2210 / 3310</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono tabular-nums text-indigo-400">
                {stats.finraViolations}
              </span>
              <span className="text-[11px] text-slate-400 font-mono">Promissory / AML</span>
            </div>
          </div>

          {/* HIPAA Violations */}
          <div 
            onClick={() => onFilterByDomain && onFilterByDomain('HIPAA')}
            className="bg-slate-950/80 border border-slate-800 p-3 rounded-lg flex flex-col justify-between cursor-pointer hover:border-slate-700 transition-colors"
          >
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>HIPAA Breaches</span>
              <span className="text-[10px] font-mono text-emerald-400">45 CFR § 164</span>
            </div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-xl font-bold font-mono tabular-nums text-emerald-400">
                {stats.hipaaViolations}
              </span>
              <span className="text-[11px] text-slate-400 font-mono">PHI / Credentials</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
