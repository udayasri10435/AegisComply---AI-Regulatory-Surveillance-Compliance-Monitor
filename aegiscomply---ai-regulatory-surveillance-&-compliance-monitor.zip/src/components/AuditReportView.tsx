import React, { useState } from 'react';
import { 
  FileText, 
  Sparkles, 
  Download, 
  Printer, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  Calendar,
  Building,
  UserCheck,
  AlertOctagon
} from 'lucide-react';
import { SurveillanceEvent } from '../types/compliance';
import { generateAuditReport } from '../services/complianceApi';

interface AuditReportViewProps {
  events: SurveillanceEvent[];
}

export const AuditReportView: React.FC<AuditReportViewProps> = ({ events }) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [report, setReport] = useState<any | null>(null);

  const violationEvents = events.filter(e => e.analysis?.isViolation);

  const handleGenerate = async () => {
    setIsGenerating(true);
    try {
      const data = await generateAuditReport(violationEvents, 'Continuous SEC, FINRA & HIPAA Perimeter');
      setReport(data);
    } catch (err) {
      console.error('Audit report error:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownloadMarkdown = () => {
    if (!report) return;
    const md = `# ${report.reportTitle}
Reference: ${report.referenceNumber || 'MEMO-SURV-2026'}
Generated: ${report.generatedAt || new Date().toISOString()}
Supervisory Perimeter: SEC Rule 17a-4 / 10b-5, FINRA 2210 / 3310, HIPAA 45 CFR § 164

## Executive Summary
${report.executiveSummary}

## Critical Regulatory Exposures
${(report.criticalExposures || []).map((e: string) => `- ${e}`).join('\n')}

## Systemic Patterns Identified
${(report.systemicPatternsIdentified || []).map((p: string) => `- ${p}`).join('\n')}

## Mandatory Regulatory Filing Obligations
${(report.regulatoryFilingObligations || []).map((f: any) => `### ${f.agency}: ${f.obligation}\n- Deadline: ${f.deadline}\n- Mandatory: ${f.mandatory ? 'Yes' : 'No'}`).join('\n\n')}

## Corrective Action Plan
${(report.correctiveActionPlan || []).map((c: string) => `1. ${c}`).join('\n')}

## Supervisory Sign-Off
Role: ${report.supervisorySignOff?.role || 'Chief Compliance Officer'}
Status: ${report.supervisorySignOff?.status || 'Signed'}
Record Retention Requirement: ${report.supervisorySignOff?.recommendedRetentionYears || 7} Years (SEC Rule 17a-4 compliant)
`;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Supervisory-Compliance-Audit-${new Date().toISOString().slice(0, 10)}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadCSV = () => {
    const headers = ['ID', 'Timestamp', 'Channel', 'Sender', 'Recipient', 'Domain', 'Category', 'Severity', 'RiskScore', 'Status'];
    const rows = events.map(e => [
      e.id,
      e.timestamp,
      `"${e.channel}"`,
      `"${e.sender}"`,
      `"${e.recipient}"`,
      e.analysis?.domain || 'N/A',
      `"${e.analysis?.category || 'N/A'}"`,
      e.analysis?.severity || 'clean',
      e.analysis?.riskScore || 0,
      e.status
    ]);

    const csvContent = [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Surveillance-Incident-Log-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Action Header */}
      <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <FileText className="w-5 h-5 text-cyan-400" />
            <span>Supervisory Compliance Audit Memorandum</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Formal regulatory disclosure document synthesis for Chief Compliance Officer (CCO) and regulatory examination review.
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleDownloadCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
            title="Export CSV log of all events"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          {report && (
            <>
              <button
                onClick={handleDownloadMarkdown}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>Export Markdown</span>
              </button>
              <button
                onClick={handlePrint}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-medium transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print / PDF</span>
              </button>
            </>
          )}

          <button
            onClick={handleGenerate}
            disabled={isGenerating}
            className="flex items-center gap-2 px-4 py-1.5 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white rounded-lg text-xs font-medium shadow-md shadow-blue-500/20 disabled:opacity-50 transition-all"
          >
            {isGenerating ? (
              <>
                <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Synthesizing Audit Memo...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate CCO Audit Memo</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Main Memorandum Display */}
      {!report && !isGenerating && (
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-12 text-center text-slate-500">
          <FileText className="w-12 h-12 mx-auto text-slate-700 mb-3" />
          <h3 className="text-sm font-semibold text-slate-300">No Regulatory Memorandum Generated Yet</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
            Click "Generate CCO Audit Memo" to synthesize a comprehensive supervisory analysis of all intercepted SEC, FINRA, and HIPAA violations using Gemini 3.8.
          </p>
        </div>
      )}

      {isGenerating && (
        <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-12 text-center text-slate-400 space-y-3">
          <div className="w-8 h-8 border-2 border-cyan-500/20 border-t-cyan-400 rounded-full animate-spin mx-auto" />
          <p className="text-xs font-mono">Aggregating incident cross-correlations and drafting statutory exposure review...</p>
        </div>
      )}

      {report && (
        <div className="bg-slate-950 border border-slate-800 rounded-xl p-8 shadow-2xl space-y-8 font-['Plus_Jakarta_Sans'] max-w-5xl mx-auto print:border-none print:shadow-none print:bg-white print:text-black">
          
          {/* Memo Header Strip */}
          <div className="border-b border-slate-800 pb-6 print:border-slate-300">
            <div className="flex items-center justify-between text-xs text-slate-400 font-mono mb-2">
              <span className="text-cyan-400 font-bold uppercase tracking-wider">
                CONFIDENTIAL // SUPERVISORY COMPLIANCE RECORD
              </span>
              <span>{report.referenceNumber || 'MEMO-SEC-FINRA-HIPAA-2026'}</span>
            </div>

            <h1 className="text-xl font-bold text-white print:text-black">
              {report.reportTitle}
            </h1>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4 pt-4 border-t border-slate-900 text-xs">
              <div>
                <span className="text-slate-500 block text-[11px] font-mono">DATE OF REVIEW</span>
                <span className="text-slate-300 font-medium">
                  {new Date(report.generatedAt || Date.now()).toLocaleDateString()}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px] font-mono">JURISDICTION</span>
                <span className="text-slate-300 font-medium">SEC · FINRA · HIPAA</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px] font-mono">INCIDENTS REVIEWED</span>
                <span className="text-slate-300 font-medium font-mono">
                  {violationEvents.length} Actionable Breaches
                </span>
              </div>
              <div>
                <span className="text-slate-500 block text-[11px] font-mono">RETENTION OBLIGATION</span>
                <span className="text-slate-300 font-medium font-mono">
                  {report.supervisorySignOff?.recommendedRetentionYears || 7} Years (WORM Compliant)
                </span>
              </div>
            </div>
          </div>

          {/* Section: Executive Summary */}
          <div className="space-y-2">
            <h2 className="text-xs font-mono uppercase text-cyan-400 tracking-wider font-bold">
              01. Executive Summary & Surveillance Scope
            </h2>
            <p className="text-xs text-slate-300 print:text-slate-800 leading-relaxed bg-slate-900/60 print:bg-slate-50 p-4 rounded-lg border border-slate-800 print:border-slate-200">
              {report.executiveSummary}
            </p>
          </div>

          {/* Section: Critical Regulatory Exposures */}
          <div className="space-y-3">
            <h2 className="text-xs font-mono uppercase text-rose-400 tracking-wider font-bold flex items-center gap-2">
              <AlertOctagon className="w-4 h-4" />
              <span>02. Material Regulatory Exposure Findings</span>
            </h2>
            <div className="grid grid-cols-1 gap-2.5">
              {(report.criticalExposures || []).map((exposure: string, idx: number) => (
                <div key={idx} className="p-3 bg-rose-950/20 border border-rose-900/40 rounded-lg text-xs text-slate-200 print:text-slate-900 flex items-start gap-2.5">
                  <span className="text-rose-400 font-mono font-bold">{idx + 1}.</span>
                  <span>{exposure}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Systemic Patterns */}
          <div className="space-y-3">
            <h2 className="text-xs font-mono uppercase text-amber-400 tracking-wider font-bold">
              03. Systemic Operational Patterns & Root Causes
            </h2>
            <div className="space-y-2">
              {(report.systemicPatternsIdentified || []).map((pattern: string, idx: number) => (
                <div key={idx} className="p-3 bg-slate-900 border border-slate-800 rounded-lg text-xs text-slate-300 print:text-slate-800 flex items-start gap-2.5">
                  <span className="text-amber-400 font-mono font-bold">•</span>
                  <span>{pattern}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Statutory Filing Obligations */}
          <div className="space-y-3">
            <h2 className="text-xs font-mono uppercase text-cyan-400 tracking-wider font-bold">
              04. Mandatory External Regulatory Filings
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(report.regulatoryFilingObligations || []).map((filing: any, idx: number) => (
                <div key={idx} className="p-3.5 bg-slate-900/90 border border-slate-800 rounded-lg text-xs space-y-2">
                  <div className="flex items-center justify-between font-mono font-bold">
                    <span className="text-cyan-400">{filing.agency}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${filing.mandatory ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-slate-800 text-slate-400'}`}>
                      {filing.mandatory ? 'MANDATORY' : 'DISCRETIONARY'}
                    </span>
                  </div>
                  <p className="text-slate-200 font-medium text-xs leading-snug">
                    {filing.obligation}
                  </p>
                  <div className="text-[11px] text-slate-400 font-mono pt-1 border-t border-slate-800">
                    Deadline: <span className="text-amber-400">{filing.deadline}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Corrective Action Plan */}
          <div className="space-y-3">
            <h2 className="text-xs font-mono uppercase text-emerald-400 tracking-wider font-bold">
              05. Mandated Corrective Action Plan
            </h2>
            <div className="space-y-2">
              {(report.correctiveActionPlan || []).map((action: string, idx: number) => (
                <div key={idx} className="p-3 bg-emerald-950/20 border border-emerald-900/40 rounded-lg text-xs text-slate-300 print:text-slate-900 flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{action}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Section: Supervisory Sign-off */}
          <div className="pt-6 border-t border-slate-800 print:border-slate-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs font-mono">
            <div>
              <span className="text-slate-500 block text-[11px]">SUPERVISORY ATTESTATION</span>
              <span className="text-slate-200 font-semibold">
                {report.supervisorySignOff?.role || 'Chief Compliance Officer & Legal Counsel'}
              </span>
            </div>
            <div className="text-right">
              <span className="text-slate-500 block text-[11px]">AUDIT STATUS</span>
              <span className="text-emerald-400 font-bold uppercase">
                {report.supervisorySignOff?.status || 'FORMAL FINDING RECORDED'}
              </span>
            </div>
          </div>

        </div>
      )}
    </div>
  );
};
