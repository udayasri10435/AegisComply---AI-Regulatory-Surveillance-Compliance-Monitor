import React, { useState } from 'react';
import { 
  SlidersHorizontal, 
  Plus, 
  ShieldCheck, 
  ShieldAlert, 
  Check, 
  X, 
  ToggleLeft, 
  ToggleRight,
  Sparkles,
  Info
} from 'lucide-react';
import { CompliancePolicyRule, RegulatoryAgency } from '../types/compliance';

interface PolicyRulesViewProps {
  rules: CompliancePolicyRule[];
  onToggleRule: (id: string) => void;
  onAddRule: (rule: CompliancePolicyRule) => void;
}

export const PolicyRulesView: React.FC<PolicyRulesViewProps> = ({
  rules,
  onToggleRule,
  onAddRule,
}) => {
  const [filterAgency, setFilterAgency] = useState<RegulatoryAgency | 'ALL'>('ALL');
  const [showAddModal, setShowAddModal] = useState(false);

  // New Rule Form State
  const [newRuleName, setNewRuleName] = useState('');
  const [newRuleAgency, setNewRuleAgency] = useState<RegulatoryAgency>('SEC');
  const [newRuleCode, setNewRuleCode] = useState('');
  const [newRuleDesc, setNewRuleDesc] = useState('');
  const [newRuleAction, setNewRuleAction] = useState<CompliancePolicyRule['actionOnTrigger']>('quarantine');
  const [newRuleSeverity, setNewRuleSeverity] = useState<CompliancePolicyRule['severity']>('high');

  const filteredRules = rules.filter(r => {
    if (filterAgency !== 'ALL' && r.agency !== filterAgency) return false;
    return true;
  });

  const handleCreateRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newRuleName.trim() || !newRuleCode.trim()) return;

    const newRule: CompliancePolicyRule = {
      id: `pol-custom-${Date.now().toString().slice(-4)}`,
      name: newRuleName,
      agency: newRuleAgency,
      ruleCode: newRuleCode,
      description: newRuleDesc || 'Custom supervisory rule definition.',
      enabled: true,
      severity: newRuleSeverity,
      actionOnTrigger: newRuleAction,
      detectionType: 'ai_semantic'
    };

    onAddRule(newRule);
    setShowAddModal(false);
    setNewRuleName('');
    setNewRuleCode('');
    setNewRuleDesc('');
  };

  return (
    <div className="space-y-6">
      {/* Policy Rules Header */}
      <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <SlidersHorizontal className="w-5 h-5 text-cyan-400" />
            <span>Regulatory Surveillance Policy Engine</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure active statutory rule sets, automatic quarantine triggers, and supervisory action thresholds.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Agency Filter */}
          <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg">
            {(['ALL', 'SEC', 'FINRA', 'HIPAA'] as const).map(regime => (
              <button
                key={regime}
                onClick={() => setFilterAgency(regime)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  filterAgency === regime
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {regime}
              </button>
            ))}
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-xs font-medium shadow-sm transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Policy Rule</span>
          </button>
        </div>
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredRules.map(rule => {
          const agencyColor = 
            rule.agency === 'SEC' ? 'text-cyan-400' :
            rule.agency === 'FINRA' ? 'text-indigo-400' :
            'text-emerald-400';

          return (
            <div
              key={rule.id}
              className={`p-4 rounded-xl border transition-all ${
                rule.enabled
                  ? 'bg-slate-950/80 border-slate-800'
                  : 'bg-slate-950/30 border-slate-900 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 text-xs mb-1">
                    <span className={`font-mono font-bold ${agencyColor}`}>
                      {rule.agency}
                    </span>
                    <span aria-hidden="true" className="text-slate-700">·</span>
                    <span className="font-mono text-slate-400 text-[11px]">
                      {rule.ruleCode}
                    </span>
                    <span aria-hidden="true" className="text-slate-700">·</span>
                    <span className="font-mono text-[10px] text-slate-500 uppercase">
                      {rule.detectionType}
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold text-slate-200">
                    {rule.name}
                  </h3>
                </div>

                <button
                  onClick={() => onToggleRule(rule.id)}
                  className="text-slate-400 hover:text-white transition-colors"
                  title={rule.enabled ? 'Disable Surveillance Rule' : 'Enable Surveillance Rule'}
                >
                  {rule.enabled ? (
                    <ToggleRight className="w-7 h-7 text-cyan-400" />
                  ) : (
                    <ToggleLeft className="w-7 h-7 text-slate-600" />
                  )}
                </button>
              </div>

              <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                {rule.description}
              </p>

              <div className="mt-4 pt-3 border-t border-slate-900 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px]">Action on breach:</span>
                  <span className="font-mono uppercase font-semibold text-slate-300 text-[11px]">
                    {rule.actionOnTrigger.replace('_', ' ')}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px]">Severity:</span>
                  <span className={`font-mono uppercase font-bold text-[11px] ${
                    rule.severity === 'critical' ? 'text-rose-400' :
                    rule.severity === 'high' ? 'text-amber-400' : 'text-yellow-400'
                  }`}>
                    {rule.severity}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Custom Policy Rule Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl shadow-2xl max-w-lg w-full p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
                <span>Define New Regulatory Policy Rule</span>
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateRule} className="space-y-3.5">
              <div>
                <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                  Policy Name
                </label>
                <input
                  type="text"
                  required
                  value={newRuleName}
                  onChange={e => setNewRuleName(e.target.value)}
                  placeholder="e.g. SEC Unregistered Token Promotion Ban"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                    Regulatory Agency
                  </label>
                  <select
                    value={newRuleAgency}
                    onChange={e => setNewRuleAgency(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                    <option value="SEC">SEC</option>
                    <option value="FINRA">FINRA</option>
                    <option value="HIPAA">HIPAA</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                    Statutory Rule Code
                  </label>
                  <input
                    type="text"
                    required
                    value={newRuleCode}
                    onChange={e => setNewRuleCode(e.target.value)}
                    placeholder="e.g. 17 CFR § 240.15c2-11"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                  Surveillance Logic Description
                </label>
                <textarea
                  rows={3}
                  value={newRuleDesc}
                  onChange={e => setNewRuleDesc(e.target.value)}
                  placeholder="Specify the condition that triggers this compliance violation..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 focus:outline-none focus:border-blue-500 leading-relaxed"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                    Action on Trigger
                  </label>
                  <select
                    value={newRuleAction}
                    onChange={e => setNewRuleAction(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                    <option value="quarantine">Auto-Quarantine Payload</option>
                    <option value="alert_cco">Immediate Alert to CCO</option>
                    <option value="flag_supervision">Flag for Supervisor Review</option>
                    <option value="log_only">Audit Log Only</option>
                  </select>
                </div>

                <div>
                  <label className="text-[11px] font-mono text-slate-400 uppercase tracking-wider block mb-1">
                    Severity Level
                  </label>
                  <select
                    value={newRuleSeverity}
                    onChange={e => setNewRuleSeverity(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 focus:outline-none focus:border-blue-500"
                  >
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-blue-600 hover:bg-blue-500 text-white text-xs font-medium rounded-md shadow-sm"
                >
                  Save Policy Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
