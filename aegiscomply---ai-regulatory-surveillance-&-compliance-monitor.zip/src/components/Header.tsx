import React from 'react';
import { 
  ShieldAlert, 
  Activity, 
  Play, 
  Pause, 
  SlidersHorizontal, 
  FileText, 
  Radio, 
  Cpu, 
  Sparkles,
  Zap
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'stream' | 'sandbox' | 'policies' | 'audit_memo';
  setActiveTab: (tab: 'stream' | 'sandbox' | 'policies' | 'audit_memo') => void;
  isStreaming: boolean;
  setIsStreaming: (val: boolean) => void;
  streamSpeed: number;
  setStreamSpeed: (val: number) => void;
  serverStatus: { status: string; geminiEnabled: boolean; engine: string };
  quarantinedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isStreaming,
  setIsStreaming,
  streamSpeed,
  setStreamSpeed,
  serverStatus,
  quarantinedCount,
}) => {
  return (
    <header className="border-b border-slate-800 bg-slate-950/90 backdrop-blur sticky top-0 z-30">
      {/* Top Banner with Regimes & Engine */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-indigo-500 via-blue-600 to-cyan-500 p-0.5 shadow-lg shadow-blue-500/20 flex items-center justify-center">
              <div className="w-full h-full bg-slate-950 rounded-[7px] flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-cyan-400" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold tracking-tight text-white font-['Plus_Jakarta_Sans']">
                  AegisComply
                </span>
                <span className="text-xs font-semibold text-cyan-400 border border-cyan-800/60 bg-cyan-950/50 px-1.5 py-0.5 rounded">
                  v3.8 SURVEILLANCE
                </span>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-400">
                <span>SEC Rule 17a-4 / 10b-5</span>
                <span aria-hidden="true">·</span>
                <span>FINRA 2210 / 3310</span>
                <span aria-hidden="true">·</span>
                <span>HIPAA 45 CFR § 164</span>
              </div>
            </div>
          </div>

          {/* Navigation Controls */}
          <nav className="flex items-center gap-1 bg-slate-900/90 p-1 border border-slate-800 rounded-lg">
            <button
              onClick={() => setActiveTab('stream')}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'stream'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Radio className="w-3.5 h-3.5" />
              <span>Live Surveillance</span>
            </button>
            <button
              onClick={() => setActiveTab('sandbox')}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'sandbox'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Scanner Sandbox</span>
            </button>
            <button
              onClick={() => setActiveTab('policies')}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'policies'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Policy Rules</span>
            </button>
            <button
              onClick={() => setActiveTab('audit_memo')}
              className={`flex items-center gap-2 px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                activeTab === 'audit_memo'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Supervisory Audit Memo</span>
            </button>
          </nav>

          {/* Live Ingestion Stream Controls */}
          <div className="flex items-center gap-3">
            {/* Live Stream Play/Pause & Speed */}
            <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1">
              <div className="flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isStreaming ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                <span className="text-xs font-medium text-slate-300">
                  {isStreaming ? 'STREAMING' : 'PAUSED'}
                </span>
              </div>
              <button
                onClick={() => setIsStreaming(!isStreaming)}
                className="p-1 text-slate-400 hover:text-white transition-colors"
                title={isStreaming ? 'Pause Simulated Ingestion Stream' : 'Resume Simulated Ingestion Stream'}
              >
                {isStreaming ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>
              <div className="h-3 w-px bg-slate-700" />
              <button
                onClick={() => setStreamSpeed(streamSpeed === 1 ? 2 : streamSpeed === 2 ? 4 : 1)}
                className="text-[11px] font-mono font-medium text-slate-400 hover:text-cyan-400 transition-colors"
                title="Toggle Ingestion Frequency Rate"
              >
                {streamSpeed}x SPEED
              </button>
            </div>

            {/* AI Engine Status Badge */}
            <div className="flex items-center gap-1.5 text-xs px-2.5 py-1 bg-slate-900 border border-slate-800 rounded-lg text-slate-400">
              <Cpu className={`w-3.5 h-3.5 ${serverStatus.geminiEnabled ? 'text-cyan-400' : 'text-amber-400'}`} />
              <span className="font-mono text-[11px]">
                {serverStatus.geminiEnabled ? 'Gemini 3.8' : 'Rule Engine'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
