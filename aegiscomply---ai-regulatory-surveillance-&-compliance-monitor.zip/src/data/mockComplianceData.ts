import { SurveillanceEvent, CompliancePolicyRule } from '../types/compliance';

export const INITIAL_POLICY_RULES: CompliancePolicyRule[] = [
  {
    id: 'pol-sec-17a4',
    name: 'SEC Rule 17a-4 Off-Channel Messaging Prohibition',
    agency: 'SEC',
    ruleCode: '17 CFR § 240.17a-4',
    description: 'Detects solicitation or redirection to unarchived external channels (WhatsApp, Signal, Telegram, personal SMS/email) for regulated investment banking or brokerage activities.',
    enabled: true,
    severity: 'high',
    actionOnTrigger: 'quarantine',
    detectionType: 'hybrid'
  },
  {
    id: 'pol-sec-10b5',
    name: 'SEC Rule 10b-5 Material Non-Public Information (MNPI)',
    agency: 'SEC',
    ruleCode: '17 CFR § 240.10b-5',
    description: 'Surveillance for references to confidential earnings revisions, M&A transactions, FDA drug trial verdicts, or executive changes prior to public release.',
    enabled: true,
    severity: 'critical',
    actionOnTrigger: 'alert_cco',
    detectionType: 'ai_semantic'
  },
  {
    id: 'pol-finra-2210',
    name: 'FINRA Rule 2210 Communications with the Public (Promissory Language)',
    agency: 'FINRA',
    ruleCode: 'FINRA Rule 2210(d)(1)',
    description: 'Identifies unwarranted guarantees, risk-free claims, unbalanced upside projections, and failure to provide required risk disclosures.',
    enabled: true,
    severity: 'high',
    actionOnTrigger: 'flag_supervision',
    detectionType: 'ai_semantic'
  },
  {
    id: 'pol-finra-3310',
    name: 'FINRA Rule 3310 / BSA Anti-Structuring Surveillance',
    agency: 'FINRA',
    ruleCode: 'FINRA Rule 3310 & 31 U.S.C. § 5324',
    description: 'Flags wire instructions or deposit patterns structured intentionally below the $10,000 Currency Transaction Report (CTR) threshold.',
    enabled: true,
    severity: 'critical',
    actionOnTrigger: 'alert_cco',
    detectionType: 'hybrid'
  },
  {
    id: 'pol-finra-5270',
    name: 'FINRA Rule 5270 Front-Running Block Order Transactions',
    agency: 'FINRA',
    ruleCode: 'FINRA Rule 5270',
    description: 'Monitors institutional trader chat and proprietary books for personal/firm positioning prior to executing client block orders.',
    enabled: true,
    severity: 'critical',
    actionOnTrigger: 'alert_cco',
    detectionType: 'ai_semantic'
  },
  {
    id: 'pol-hipaa-phi',
    name: 'HIPAA 45 CFR § 164.502 Unauthorized PHI Disclosure',
    agency: 'HIPAA',
    ruleCode: '45 CFR § 164.502(a)',
    description: 'Flags unprotected transmission of 18 HIPAA identifiers (Names, SSN, MRN, DOB) combined with medical diagnostics, pathology reports, or medication lists.',
    enabled: true,
    severity: 'critical',
    actionOnTrigger: 'quarantine',
    detectionType: 'hybrid'
  },
  {
    id: 'pol-hipaa-min-nec',
    name: 'HIPAA Minimum Necessary Standard',
    agency: 'HIPAA',
    ruleCode: '45 CFR § 164.502(b)',
    description: 'Detects broadcasting granular patient records or psychiatric/social histories to broad staff channels beyond what is clinically required.',
    enabled: true,
    severity: 'medium',
    actionOnTrigger: 'flag_supervision',
    detectionType: 'ai_semantic'
  },
  {
    id: 'pol-hipaa-sec-cred',
    name: 'HIPAA 45 CFR § 164.312 Transmission & Access Safeguards',
    agency: 'HIPAA',
    ruleCode: '45 CFR § 164.312(a)(2)(i)',
    description: 'Catches transmission of EHR credentials, root passwords, or remote login links over unencrypted internal communication channels.',
    enabled: true,
    severity: 'high',
    actionOnTrigger: 'quarantine',
    detectionType: 'hybrid'
  }
];

export const INITIAL_SURVEILLANCE_EVENTS: SurveillanceEvent[] = [
  {
    id: 'EVT-2026-9041',
    timestamp: '2026-09-29T08:14:22Z',
    type: 'communication',
    channel: 'Email (Exchange)',
    sender: 'marcus.vance@apexcapitalllc.com',
    senderRole: 'Senior Managing Director',
    senderDepartment: 'Wealth Management Desk',
    recipient: 'richard.brennan@familyoffice-sf.com',
    recipientRole: 'External Ultra-High-Net-Worth Client',
    subjectOrIdentifier: 'Confidential Allocation Details - Off Channel',
    content: 'Hi Richard, compliance archives our corporate Outlook so please do not reply here. Text me directly on my personal WhatsApp (+1-415-555-0812) or Signal. I have the unreleased private allocation term sheet and want to get your commitment before the morning syndicate call.',
    metadata: {
      clientAccount: 'WM-882194',
      aumTier: 'Tier 1 ($25M+)',
      externalEmail: true
    },
    status: 'quarantined',
    quarantinedAt: '2026-09-29T08:14:23Z',
    analysis: {
      isViolation: true,
      severity: 'high',
      riskScore: 89,
      domain: 'SEC',
      category: 'Unapproved Off-Channel Communication',
      regulationsViolated: [
        {
          code: 'SEC Rule 17a-4 / Exchange Act § 17(a)',
          title: 'Books and Records Preservation for Electronic Communications',
          agency: 'SEC',
          severity: 'high',
          summary: 'Explicit solicitation to migrate regulated investment allocation discussions from official archived systems to unmonitored personal messaging platforms (WhatsApp/Signal).'
        },
        {
          code: 'FINRA Rule 3110',
          title: 'Supervisory Systems for Correspondence and Internal Communications',
          agency: 'FINRA',
          severity: 'high',
          summary: 'Firm failed to prevent broker evasion of supervisory inspection through intentional redirection of client dialogue.'
        }
      ],
      flaggedSnippets: [
        {
          text: 'compliance archives our corporate Outlook so please do not reply here. Text me directly on my personal WhatsApp (+1-415-555-0812) or Signal.',
          riskReason: 'Direct attempt to circumvent electronic surveillance and recordkeeping obligations under SEC Rule 17a-4.',
          riskLevel: 'critical'
        },
        {
          text: 'I have the unreleased private allocation term sheet and want to get your commitment before the morning syndicate call.',
          riskReason: 'Selective disclosure of confidential allocation materials prior to formal syndicate distribution.',
          riskLevel: 'warning'
        }
      ],
      summary: 'High-severity SEC Rule 17a-4 violation. Senior Managing Director explicitly instructed an external high-net-worth client to circumvent firm archiving by communicating on personal WhatsApp and Signal regarding private allocation terms.',
      intentAssessment: 'intentional',
      remediationAction: 'Quarantine email immediately. Suspend employee outbound external messaging privileges. Initiate formal Supervisory Investigation with Chief Compliance Officer.',
      supervisoryChecklist: [
        'Place Marcus Vance on immediate communications retention hold',
        'Issue Preservation Notice for personal device WhatsApp/Signal logs',
        'Document incident on Form BD quarterly supervisory record',
        'Schedule mandatory compliance remediation interview within 24 hours'
      ],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T08:14:23Z'
    }
  },
  {
    id: 'EVT-2026-9042',
    timestamp: '2026-09-29T08:21:05Z',
    type: 'communication',
    channel: 'Bloomberg Chat',
    sender: 'derek.stone@apexcapitalllc.com',
    senderRole: 'Equities Prop Desk Trader',
    senderDepartment: 'Institutional Trading',
    recipient: 'elena.rostova@summit-alpha-fund.com',
    recipientRole: 'Hedge Fund Portfolio Manager',
    subjectOrIdentifier: 'Chat Room: #TMT-Flows-Alpha',
    content: 'Derek: Heard from our advisory team that Biogenix (BGNX) buyout will close at $78 cash tomorrow morning at 7:00 AM before the bell. Board signed an hour ago. We are accumulating 120k call contracts right now. Get your book in before 4:00 PM.',
    metadata: {
      securityTicker: 'BGNX',
      orderValueEstimate: '$4,800,000',
      chatRoom: '#TMT-Flows-Alpha'
    },
    status: 'escalated',
    analysis: {
      isViolation: true,
      severity: 'critical',
      riskScore: 98,
      domain: 'SEC',
      category: 'Material Non-Public Information (MNPI) / Insider Trading',
      regulationsViolated: [
        {
          code: 'SEC Rule 10b-5 / Securities Exchange Act § 10(b)',
          title: 'Employment of Manipulative and Deceptive Devices (Insider Tipping)',
          agency: 'SEC',
          severity: 'critical',
          summary: 'Dissemination of confidential, unannounced merger price ($78/share) and board approval timing with an explicit directive to front-run the public market announcement.'
        },
        {
          code: 'FINRA Rule 2010',
          title: 'Standards of Commercial Honor and Principles of Trade',
          agency: 'FINRA',
          severity: 'critical',
          summary: 'Gross violation of market integrity principles and breach of internal information barrier (Chinese Wall).'
        }
      ],
      flaggedSnippets: [
        {
          text: 'Heard from our advisory team that Biogenix (BGNX) buyout will close at $78 cash tomorrow morning at 7:00 AM before the bell. Board signed an hour ago.',
          riskReason: 'Unauthorized leakage of Material Non-Public Information sourced across internal information barriers.',
          riskLevel: 'critical'
        },
        {
          text: 'We are accumulating 120k call contracts right now. Get your book in before 4:00 PM.',
          riskReason: 'Active insider tipping and inducement to execute speculative derivative positions ahead of material public disclosure.',
          riskLevel: 'critical'
        }
      ],
      summary: 'Critical SEC Rule 10b-5 MNPI / Insider Trading breach. Equities trader leaked confidential M&A acquisition details obtained from firm advisory division and recommended options accumulation prior to market disclosure.',
      intentAssessment: 'intentional',
      remediationAction: 'CRITICAL ESCALATION: Immediately notify Legal & CCO. Freeze trading on BGNX across all firm prop and customer accounts. Place communication and trading records on litigation hold.',
      supervisoryChecklist: [
        'Transmit urgent alert to General Counsel and Head of Surveillance',
        'Add BGNX immediately to Firm Grey/Restricted List',
        'Freeze trade execution authorizations for Derek Stone pending interrogation',
        'Prepare Form U4/U5 disclosure draft and draft SEC Enforcement voluntary disclosure dossier'
      ],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T08:21:06Z'
    }
  },
  {
    id: 'EVT-2026-9043',
    timestamp: '2026-09-29T08:33:14Z',
    type: 'communication',
    channel: 'Email (Exchange)',
    sender: 'claire.morrison@stjude-healthsystem.org',
    senderRole: 'Clinical Nurse Coordinator',
    senderDepartment: 'Oncology Center',
    recipient: 'vendor-ops@medbill-analytics-external.com',
    recipientRole: 'Third-Party Billing Contractor',
    subjectOrIdentifier: 'Batch Patient Records - September Oncology Diagnostic Rosters',
    content: 'Good morning, please find the diagnostic patient roster below for reconciliation. Patient: Anderson, Robert (DOB: 11/04/1971, SSN: 219-44-8891, MRN: #ONC-4491) diagnosed with Stage IV Metastatic Pancreatic Adenocarcinoma, prescribed Gemcitabine 1400mg; Patient: Martinez, Elena (DOB: 03/15/1988, SSN: 541-22-9014, MRN: #ONC-4502) confirmed positive for BRCA1 mutation with bilateral mastectomy pending.',
    metadata: {
      patientsCount: 2,
      encryptionStatus: 'Unencrypted (TLS Opportunistic)',
      containsSSN: true
    },
    status: 'quarantined',
    quarantinedAt: '2026-09-29T08:33:15Z',
    analysis: {
      isViolation: true,
      severity: 'critical',
      riskScore: 96,
      domain: 'HIPAA',
      category: 'Protected Health Information (PHI) Unauthorized Exposure',
      regulationsViolated: [
        {
          code: '45 CFR § 164.502(a)',
          title: 'HIPAA Privacy Rule - General Rules for Uses and Disclosures of PHI',
          agency: 'HIPAA',
          severity: 'critical',
          summary: 'Transmitted full direct patient identifiers (SSNs, DOBs, full legal names, MRNs) linked to sensitive clinical cancer diagnoses over standard external email.'
        },
        {
          code: '45 CFR § 164.312(e)(1)',
          title: 'HIPAA Security Rule - Technical Safeguards: Transmission Security',
          agency: 'HIPAA',
          severity: 'high',
          summary: 'Failure to enforce end-to-end payload encryption and secure SFTP/API transport mechanisms for bulk ePHI exchange.'
        },
        {
          code: '45 CFR § 164.502(b)',
          title: 'HIPAA Minimum Necessary Standard',
          agency: 'HIPAA',
          severity: 'high',
          summary: 'Billing reconciliation does not require full unredacted SSN and clinical stage details; masked tokens should have been utilized.'
        }
      ],
      flaggedSnippets: [
        {
          text: 'Patient: Anderson, Robert (DOB: 11/04/1971, SSN: 219-44-8891, MRN: #ONC-4491) diagnosed with Stage IV Metastatic Pancreatic Adenocarcinoma',
          riskReason: 'Direct exposure of 18 statutory HIPAA identifiers coupled with sensitive oncology diagnostic data.',
          riskLevel: 'critical'
        },
        {
          text: 'Patient: Martinez, Elena (DOB: 03/15/1988, SSN: 541-22-9014, MRN: #ONC-4502) confirmed positive for BRCA1 mutation with bilateral mastectomy pending.',
          riskReason: 'Genetic information (BRCA1) and surgical records exposed in cleartext email body.',
          riskLevel: 'critical'
        }
      ],
      summary: 'Severe HIPAA Privacy & Security Rule violation. Direct, unencrypted disclosure of patient names, Social Security Numbers, MRNs, and Stage IV cancer / genetic diagnoses to an external contractor in standard email body.',
      intentAssessment: 'negligent',
      remediationAction: 'Quarantine email transmission immediately. Recall external message if possible. Trigger HIPAA Breach Risk Assessment (45 CFR § 164.402) with Privacy Officer.',
      supervisoryChecklist: [
        'Notify Chief Privacy Officer (CPO) and Information Security Officer',
        'Verify whether Business Associate Agreement (BAA) is in place with Medbill Analytics',
        'Execute 4-factor HIPAA risk assessment to determine if breach threshold is crossed for HHS OCR notification',
        'Mandate immediate employee retraining on secure SFTP transmission protocols'
      ],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T08:33:15Z'
    }
  },
  {
    id: 'EVT-2026-9044',
    timestamp: '2026-09-29T08:45:00Z',
    type: 'transaction',
    channel: 'Fedwire / Swift Transfer',
    sender: 'kevin.zhao@apexcapitalllc.com',
    senderRole: 'Operations Analyst',
    senderDepartment: 'Treasury & Settlements',
    recipient: 'Federal Reserve Bank / Wire Queue',
    subjectOrIdentifier: 'Wire Batch Instruction #WT-994101 to #WT-994105',
    content: 'Transaction Memorandum: Client instructed to execute five consecutive outward wire transfers of exactly $9,850 each from Account #ACC-77401 to five distinct offshore LLC accounts at Bank of Valetta within 45 minutes, with explicit instruction to keep each transfer below the $10,000 threshold to expedite internal processing without CTR generation.',
    metadata: {
      accountNumber: 'ACC-77401',
      totalAggregateAmount: '$49,250',
      individualTransfers: 5,
      individualAmounts: ['$9,850', '$9,850', '$9,850', '$9,850', '$9,850'],
      currency: 'USD'
    },
    status: 'investigating',
    analysis: {
      isViolation: true,
      severity: 'critical',
      riskScore: 97,
      domain: 'FINRA',
      category: 'Anti-Money Laundering (AML) Structuring',
      regulationsViolated: [
        {
          code: '31 U.S.C. § 5324 / Bank Secrecy Act',
          title: 'Structuring Transactions to Evade Reporting Requirements',
          agency: 'FINRA',
          severity: 'critical',
          summary: 'Explicit intent documented in transaction memorandum to split a $49,250 aggregate transfer into tranches under $10,000 to circumvent Currency Transaction Reporting.'
        },
        {
          code: 'FINRA Rule 3310',
          title: 'Anti-Money Laundering Compliance Program',
          agency: 'FINRA',
          severity: 'critical',
          summary: 'Member firm failed to halt structured transactions meeting statutory red flags for Suspicious Activity Report (SAR) filing.'
        }
      ],
      flaggedSnippets: [
        {
          text: 'five consecutive outward wire transfers of exactly $9,850 each ... with explicit instruction to keep each transfer below the $10,000 threshold to expedite internal processing without CTR generation.',
          riskReason: 'Textbook definition of structuring under 31 U.S.C. § 5324 and FinCEN red flag typologies.',
          riskLevel: 'critical'
        }
      ],
      summary: 'Critical Anti-Money Laundering (AML) violation. Wires intentionally structured at $9,850 to evade FinCEN Currency Transaction Report (CTR) threshold of $10,000.',
      intentAssessment: 'intentional',
      remediationAction: 'HALT ALL PENDING OUTBOUND WIRES. Freeze funds in Account #ACC-77401. Escalate to AML Compliance Officer for immediate SAR (FinCEN Form 111) drafting.',
      supervisoryChecklist: [
        'Place administrative freeze on wire batch WT-994101 through 994105',
        'Initiate formal AML enhanced due diligence (EDD) investigation',
        'File Suspicious Activity Report (SAR) within statutory 30-day window without tipping off customer',
        'Interview Operations Analyst Kevin Zhao regarding protocol for handling structured customer requests'
      ],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T08:45:01Z'
    }
  },
  {
    id: 'EVT-2026-9045',
    timestamp: '2026-09-29T09:02:18Z',
    type: 'communication',
    channel: 'Email (Exchange)',
    sender: 'bradley.cooper@apexcapitalllc.com',
    senderRole: 'Registered Representative (Series 7/66)',
    senderDepartment: 'Retail Investment Advisory',
    recipient: 'investor-outreach-list@retail-leads-q3.com',
    recipientRole: 'Prospective Retail Investors',
    subjectOrIdentifier: 'Guaranteed 35% Annual Yield Opportunity - Apex Alpha Yield Fund',
    content: 'Dear Prospective Investor, we are pleased to introduce the Apex Dynamic Yield Strategy. Backed by our institutional proprietary arbitrage models, this fund provides a 100% guaranteed 35% annual return with zero risk of capital loss. Unlike volatile equity markets, your principal is completely safe and returns are locked in regardless of macroeconomic headwinds.',
    metadata: {
      campaignId: 'RETAIL-PROMO-Q3',
      recipientListSize: 420,
      approvedBySupervision: false
    },
    status: 'open',
    analysis: {
      isViolation: true,
      severity: 'high',
      riskScore: 91,
      domain: 'FINRA',
      category: 'Misleading Public Marketing & Promissory Claims',
      regulationsViolated: [
        {
          code: 'FINRA Rule 2210(d)(1)(D)',
          title: 'Communications with the Public - Prohibition of Promissory Statements',
          agency: 'FINRA',
          severity: 'high',
          summary: 'Communications with the public may not predict or project performance, imply that past performance will recur or make any exaggerated or unwarranted claim, opinion or forecast.'
        },
        {
          code: 'FINRA Rule 2210(b)(1)',
          title: 'Supervisory Review and Approval of Retail Communications',
          agency: 'FINRA',
          severity: 'high',
          summary: 'Retail communication distributed to over 25 prospective retail investors without prior written approval by a registered principal.'
        },
        {
          code: 'SEC Marketing Rule / IA Act Rule 206(4)-1',
          title: 'Investment Adviser Marketing Standards',
          agency: 'SEC',
          severity: 'high',
          summary: 'Unsubstantiated claims of risk-free returns and failure to include fair and balanced disclosure of material risks.'
        }
      ],
      flaggedSnippets: [
        {
          text: 'this fund provides a 100% guaranteed 35% annual return with zero risk of capital loss.',
          riskReason: 'Direct violation of FINRA Rule 2210 prohibiting performance guarantees and claiming zero investment risk.',
          riskLevel: 'critical'
        },
        {
          text: 'your principal is completely safe and returns are locked in regardless of macroeconomic headwinds.',
          riskReason: 'Exaggerated and unwarranted promissory safety assurances.',
          riskLevel: 'violation'
        }
      ],
      summary: 'High-severity FINRA Rule 2210 and SEC Marketing Rule violation. Registered representative distributed unapproved marketing email to 420 retail prospects promising a guaranteed 35% return with zero capital risk.',
      intentAssessment: 'negligent',
      remediationAction: 'Issue immediate retraction and curative notice to all 420 recipients. Issue formal Written Reprimand to Bradley Cooper and initiate supervisory review of registered marketing materials.',
      supervisoryChecklist: [
        'Send mandatory retraction letter with FINRA-compliant risk disclosure',
        'Audit all outbound correspondence from Bradley Cooper for previous 90 days',
        'Submit Form U4 regulatory action disclosure amendment if disciplinary action taken',
        'Review email pre-approval automated gatekeeping rules'
      ],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T09:02:19Z'
    }
  },
  {
    id: 'EVT-2026-9046',
    timestamp: '2026-09-29T09:12:45Z',
    type: 'communication',
    channel: 'Slack',
    sender: 'dr.nathan.keller@stjude-healthsystem.org',
    senderRole: 'Attending Physician',
    senderDepartment: 'Cardiology Department',
    recipient: '#cardiology-all-staff',
    recipientRole: 'Clinical & Administrative Staff (180 Members)',
    subjectOrIdentifier: 'Slack: #cardiology-all-staff',
    content: 'Dr. Keller: Hey team, I am running behind in the cardiac cath lab. Can someone log into EPIC EHR with my credentials so you can print the patient charts? Username: nkeller_md, Password: CardiologyRocks2026! Please hurry.',
    metadata: {
      channelAudienceCount: 184,
      channelPrivacy: 'Public Internal Slack'
    },
    status: 'quarantined',
    quarantinedAt: '2026-09-29T09:12:46Z',
    analysis: {
      isViolation: true,
      severity: 'high',
      riskScore: 88,
      domain: 'HIPAA',
      category: 'EHR Access Controls & Credential Sharing',
      regulationsViolated: [
        {
          code: '45 CFR § 164.312(a)(2)(i)',
          title: 'HIPAA Security Rule - Technical Safeguards: Unique User Identification',
          agency: 'HIPAA',
          severity: 'high',
          summary: 'Broadcast of individual practitioner authentication credentials to 184 staff members destroys user accountability and audit trail integrity required under HIPAA Security Rule.'
        },
        {
          code: '45 CFR § 164.308(a)(5)(ii)(D)',
          title: 'Password Management Safeguards',
          agency: 'HIPAA',
          severity: 'high',
          summary: 'Explicit compromise of password confidentiality over an unencrypted collaborative chat tool.'
        }
      ],
      flaggedSnippets: [
        {
          text: 'Can someone log into EPIC EHR with my credentials so you can print the patient charts? Username: nkeller_md, Password: CardiologyRocks2026!',
          riskReason: 'Cleartext broadcast of EHR master login credentials to general public workplace chat channel.',
          riskLevel: 'critical'
        }
      ],
      summary: 'High-severity HIPAA Security Rule violation. Attending physician published their active EHR system username and password to a public Slack channel with 184 members.',
      intentAssessment: 'negligent',
      remediationAction: 'Immediately force reset and lock credentials for user nkeller_md in Epic Identity Management. Purge Slack message history. Escalate to Chief Information Security Officer (CISO).',
      supervisoryChecklist: [
        'Invalidate active Epic session tokens for Dr. Keller immediately',
        'Inspect Epic access logs for unauthorized sessions in the preceding 60 minutes',
        'Issue formal security violation citation to Dr. Keller',
        'Deploy Slack keyword DLP filter for credential keywords'
      ],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T09:12:46Z'
    }
  },
  {
    id: 'EVT-2026-9047',
    timestamp: '2026-09-29T09:25:30Z',
    type: 'communication',
    channel: 'Email (Exchange)',
    sender: 'sarah.jenkins@apexcapitalllc.com',
    senderRole: 'Compliance Officer',
    senderDepartment: 'Regulatory Affairs',
    recipient: 'all-registered-reps@apexcapitalllc.com',
    recipientRole: 'Registered Representatives',
    subjectOrIdentifier: 'Quarterly Regulatory Advisory - Form CRS & Annual Suitability Affirmation',
    content: 'Team, please review your client accounts to ensure updated Customer Relationship Summaries (Form CRS) have been furnished in accordance with SEC Exchange Act Rule 17a-14. Remember that past performance does not guarantee future results, and all product materials must include full disclosure of fees, volatility, and capital risk.',
    metadata: {
      approvedTemplate: true,
      disclosureStandard: 'Full SEC/FINRA Compliance'
    },
    status: 'remediated',
    analysis: {
      isViolation: false,
      severity: 'clean',
      riskScore: 2,
      domain: 'CLEAN',
      category: 'Compliant Internal Advisory',
      regulationsViolated: [],
      flaggedSnippets: [],
      summary: 'Fully compliant compliance advisory message enforcing SEC Form CRS and FINRA Rule 2210 disclosure standards with standard safe harbor language.',
      intentAssessment: 'benign',
      remediationAction: 'No action required. Archived in compliant supervisory log.',
      supervisoryChecklist: ['Standard 7-year electronic storage archive maintained.'],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T09:25:31Z'
    }
  },
  {
    id: 'EVT-2026-9048',
    timestamp: '2026-09-29T09:34:11Z',
    type: 'communication',
    channel: 'EHR / Clinical Notes',
    sender: 'dr.laura.kim@stjude-healthsystem.org',
    senderRole: 'Principal Investigator',
    senderDepartment: 'Cardiovascular Research Institute',
    recipient: 'irb-registry@nih-healthdata-exchange.gov',
    recipientRole: 'National Clinical Trials Registry',
    subjectOrIdentifier: 'Research Cohort 104 - De-Identified Dataset Transfer',
    content: 'Submitting final dataset for Study #CV-8910. All data has been de-identified in strict adherence with HIPAA Safe Harbor standards (45 CFR § 164.514(b)(2)). All 18 direct identifiers including patient names, geographic codes below state level, dates of birth, and medical record numbers have been removed and replaced with random salted hash keys. Institutional Review Board (IRB) approval #2026-IRB-771 attached.',
    metadata: {
      deIdentificationMethod: 'Safe Harbor 45 CFR 164.514(b)',
      irbProtocol: 'IRB-771',
      hipaaCompliant: true
    },
    status: 'remediated',
    analysis: {
      isViolation: false,
      severity: 'clean',
      riskScore: 3,
      domain: 'CLEAN',
      category: 'Compliant Research De-Identification',
      regulationsViolated: [],
      flaggedSnippets: [],
      summary: 'Exemplary HIPAA compliance. Dataset fully de-identified pursuant to HIPAA Privacy Rule Safe Harbor provisions under 45 CFR § 164.514 with active IRB authorization.',
      intentAssessment: 'benign',
      remediationAction: 'No action required. Transmission cleared for regulatory archive.',
      supervisoryChecklist: ['Audit token hash mapping maintained in secure vault.'],
      aiEngine: 'gemini-3.8-flash',
      analyzedAt: '2026-09-29T09:34:12Z'
    }
  }
];

export const SIMULATION_STREAM_POOL: Omit<SurveillanceEvent, 'id' | 'timestamp' | 'status'>[] = [
  {
    type: 'communication',
    channel: 'Microsoft Teams',
    sender: 'brian.walsh@apexcapitalllc.com',
    senderRole: 'Investment Banking Associate',
    senderDepartment: 'M&A Advisory',
    recipient: 'alicia.tian@quantum-partners.com',
    recipientRole: 'Private Equity Sponsor',
    subjectOrIdentifier: 'Project Titan - Pre-announcement leak',
    content: 'Alicia, between us, the Project Titan target accepted our revised $45/share offer 20 minutes ago. Regulatory filings won’t hit EDGAR until Monday 8:00 AM. If you need to rebalance your position, now is your window.',
    metadata: {
      dealCodeName: 'Project Titan',
      estimatedDealValue: '$1.4B'
    }
  },
  {
    type: 'communication',
    channel: 'SMS / iMessage',
    sender: 'jessica.mendez@stjude-healthsystem.org',
    senderRole: 'Patient Intake Specialist',
    senderDepartment: 'Neurology Clinic',
    recipient: 'charlotte.webb@family-caregiver.net',
    recipientRole: 'Patient Relative (Unverified)',
    subjectOrIdentifier: 'SMS to external mobile number',
    content: 'Hi Charlotte, your mother Dorothy Webb (MRN: NEU-8921, DOB 05/19/1944) had her Brain MRI results come back. The scan shows progressive glioblastoma multiforme. The doctor wants her in hospice consultation immediately.',
    metadata: {
      deliveryProtocol: 'Standard Cellular SMS',
      unauthorizedRecipient: true
    }
  },
  {
    type: 'communication',
    channel: 'WhatsApp (Off-Channel)',
    sender: 'garrett.reynolds@apexcapitalllc.com',
    senderRole: 'Syndicate Desk Trader',
    senderDepartment: 'Fixed Income Trading',
    recipient: 'marco.luciano@swiss-private-bank.ch',
    recipientRole: 'Overseas Institutional Buyer',
    subjectOrIdentifier: 'WhatsApp Chat: +41 79 555 4100',
    content: 'Marco, don’t email me about the high-yield sovereign paper allocation. The compliance team checks all incoming threads. Message me here on WhatsApp only. I have 15M of the 9.25% note reserved for your account.',
    metadata: {
      app: 'WhatsApp Business (Unmanaged)',
      assetClass: 'High-Yield Emerging Sovereign'
    }
  },
  {
    type: 'transaction',
    channel: 'Broker Order Route',
    sender: 'automated-algo@apexcapitalllc.com',
    senderRole: 'Quantitative Execution System',
    senderDepartment: 'High-Frequency Trading Desk',
    recipient: 'Direct Market Access (NASDAQ DMA)',
    subjectOrIdentifier: 'Order Match: AC-99104 (Wash Trade Alert)',
    content: 'Surveillance Alert: Account #PROP-882 simultaneous submitted aggressive BUY order for 80,000 shares of PLTR at $34.10 and matching internal SELL order for 80,000 shares of PLTR at $34.10 routed to internal dark pool, resulting in zero change of beneficial ownership.',
    metadata: {
      ticker: 'PLTR',
      shares: 80000,
      price: 34.10,
      beneficialOwnershipChange: false
    }
  },
  {
    type: 'communication',
    channel: 'Slack',
    sender: 'samir.patel@stjude-healthsystem.org',
    senderRole: 'Radiology Resident',
    senderDepartment: 'Diagnostic Imaging',
    recipient: '#general-discussion-hospital',
    recipientRole: 'Hospital-Wide Public Channel (650 Members)',
    subjectOrIdentifier: 'Slack: #general-discussion-hospital',
    content: 'Look at this wild chest CT scan I just took! Patient Jonathan Miller (Chart #99104, 34yo) swallowed a whole set of car keys while under severe intoxicated delirium. Here is the unredacted DICOM image link.',
    metadata: {
      attachment: 'chest_ct_miller_unredacted.dcm',
      channelMembers: 650
    }
  },
  {
    type: 'communication',
    channel: 'Email (Exchange)',
    sender: 'rachel.adams@apexcapitalllc.com',
    senderRole: 'Senior Wealth Strategist',
    senderDepartment: 'Private Wealth Advisory',
    recipient: 'william.foster@foster-trust.org',
    recipientRole: 'Trustee Client',
    subjectOrIdentifier: 'Re: Annual Portfolio Review & Asset Allocation Rebalance',
    content: 'Dear Mr. Foster, following our quarterly review, we recommend rebalancing 5% from fixed income into the broad market index ETF to align with your approved Moderate Growth IPS mandate. As required by SEC Reg Best Interest, enclosed are the prospectus, fee disclosures, and historical variance metrics. Past performance is no guarantee of future returns.',
    metadata: {
      ipsCompliant: true,
      disclosuresAttached: true
    }
  }
];

export const PRESET_SCAN_TEMPLATES = [
  {
    title: 'SEC Rule 17a-4 Off-Channel Solicitation',
    description: 'Wealth advisor attempting to move conversation to unarchived WhatsApp/Signal',
    agency: 'SEC' as const,
    channel: 'Email (Exchange)' as const,
    sender: 'marcus.vance@apexcapital.com',
    senderRole: 'Senior Managing Director',
    recipient: 'james.sterling@vip-client.com',
    content: 'Hey James, our compliance department has automated surveillance on company email, so do not reply to this thread. Ping me on my personal WhatsApp (+1-917-555-0149) or Signal. I will send you the confidential allocation sheet for the pre-IPO round.'
  },
  {
    title: 'SEC Rule 10b-5 Insider Tipping / MNPI',
    description: 'Analyst disclosing non-public buyout terms prior to official press release',
    agency: 'SEC' as const,
    channel: 'Bloomberg Chat' as const,
    sender: 'trader.alex@apexcapital.com',
    senderRole: 'Desk Trader',
    recipient: 'hedgefund.mike@alpha-partners.com',
    content: 'Mike, got word from our internal M&A team that the board of Novalis Therapeutics (NVLS) just signed the definitive merger agreement at $92/share. Deal goes public at 8:00 AM pre-market wire tomorrow. Buy as many call options as you can before the market closes.'
  },
  {
    title: 'FINRA Rule 2210 Guaranteed Returns & Promissory Claims',
    description: 'Broker soliciting retail customers with guaranteed 30% yield and no risk',
    agency: 'FINRA' as const,
    channel: 'Email (Exchange)' as const,
    sender: 'brett.collins@apexcapital.com',
    senderRole: 'Retail Registered Rep',
    recipient: 'retail-investors-list@leads.com',
    content: 'Invest today in our Apex Yield Growth Opportunity! Our algorithmic trading software guarantees a 30% annual return with zero risk of loss. Your money is 100% safe and returns are locked in regardless of what happens in the stock market.'
  },
  {
    title: 'HIPAA 45 CFR § 164.502 Unauthorized PHI Disclosure',
    description: 'Clinical coordinator emailing SSNs and sensitive medical diagnoses to external party',
    agency: 'HIPAA' as const,
    channel: 'Email (Exchange)' as const,
    sender: 'nurse.elizabeth@stjude-health.org',
    senderRole: 'Nurse Coordinator',
    recipient: 'support@external-consulting-agency.com',
    content: 'Attached are the patient records for reconciliation: Patient John Doe (SSN: 334-12-9844, DOB: 09/12/1979, MRN: #49102) diagnosed with HIV-1 and undergoing antiretroviral therapy. Please ensure billing claims reflect these diagnosis codes.'
  },
  {
    title: 'HIPAA Security Rule Shared Master Credentials',
    description: 'Attending physician posting EHR login password in public staff Slack',
    agency: 'HIPAA' as const,
    channel: 'Slack' as const,
    sender: 'dr.kaufman@stjude-health.org',
    senderRole: 'Chief of Medicine',
    recipient: '#general-all-staff',
    content: 'Team, I am stuck in traffic. If you need to access patient EHR files, log in using my account: username: dkaufman_admin, password: HospitalSecurePassword2026! Don’t tell IT I gave this to you.'
  },
  {
    title: 'FINRA Rule 3310 Anti-Structuring / AML Red Flag',
    description: 'Customer requesting split wires under $10,000 to evade CTR filings',
    agency: 'FINRA' as const,
    channel: 'Fedwire / Swift Transfer' as const,
    sender: 'operations.desk@apexcapital.com',
    senderRole: 'Wire Operations Analyst',
    recipient: 'Internal Wire Queue',
    content: 'Customer requested to break a $48,000 cash balance into five distinct wire transfers of $9,600 each across different days so that it does not trigger a FinCEN Currency Transaction Report (CTR).'
  },
  {
    title: 'Compliant Reg BI / Suitability Financial Communication',
    description: 'Properly disclosed wealth management IPS rebalancing with full risk notices',
    agency: 'SEC' as const,
    channel: 'Email (Exchange)' as const,
    sender: 'elena.rostova@apexcapital.com',
    senderRole: 'Certified Financial Planner',
    recipient: 'thomas.wright@family-office.com',
    content: 'Dear Mr. Wright, attached is your quarterly portfolio review. In accordance with your Investment Policy Statement and SEC Regulation Best Interest, we have rebalanced 4% from equities to fixed income. Please review the enclosed prospectuses and fee disclosures. Past performance does not guarantee future results.'
  }
];
